<?php

defined( '_JEXEC' ) or die();
jimport( 'joomla.application.component.view' );
class WebchatViewWebchat extends JView
{
    function display($tpl = null) {
	    $cf_update = JRequest::getVar('cf_update', null);
        $cf_add = JRequest::getVar('cf_add', null);
        
        $db =& JFactory::getDBO();
        $db->setQuery("SELECT * FROM #__webchat_options");
        global $webchat_options;
        $webchat_options = $db->loadObject();
        //conect to main server 
        jimport('joomla.database.database');
        jimport( 'joomla.database.table' );
        $host_op = $webchat_options->host;
        $user_op = $webchat_options->user;
        $dbase_op = $webchat_options->database;
        $password_op = $webchat_options->password;
        $driver_op = $webchat_options->d_type;
        $prefix_op = $webchat_options->prefix;
        global $options_op;
        $options_op    = array ( 'driver' => $driver_op, 'host' => $host_op, 'user' => $user_op, 'password' => $password_op, 'database' => $dbase_op, 'prefix' => $prefix_op );       
                
        if($cf_update == 1 and $cf_update != null){
            $chat = WebchatViewWebchat::cf_webchat_update();
            exit;
        }elseif($cf_add == 1 and $cf_add != null){
            $chat = WebchatViewWebchat::cf_webchat_send_message();
            exit;    
        }else{
            $chat = WebchatViewWebchat::cf_webchat_block_messages_content();
            //$chat .= WebchatViewWebchat::cf_webchat_update();
        }
        $this->assignRef( 'chat',    $chat );

        parent::display($tpl);
    }
    
    //1
    function cf_webchat_block_messages_content() {
        global $options_op;
        $temp_db =& JDatabase::getInstance( $options_op );
        $document =& JFactory::getDocument();
        $document->addStyleSheet( JURI::root().'components/com_webchat/assets/style.css', 'text/css' );
        $document->addScript(JURI::root().'components/com_webchat/assets/jquery-1.4.2.js');
        //$document->addScript(JURI::root().'components/com_webchat/assets/script.js');
  
        $channel = (empty($_COOKIE['cf_channel'])) ? '' : rawurldecode($_COOKIE['cf_channel']);
 
        if ($channel != '') {
            $temp_db->setQuery("SELECT name FROM #__cf_channels WHERE name = '".$channel."'");
            $channel_exists = $temp_db->loadResult();
        }
        if (!$channel_exists || $channel == '') {
            $temp_db->setQuery("SELECT name FROM #__cf_channels ORDER BY id ASC");
            $channel = $temp_db->loadResult();
        }

        $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions WHERE channel = '".$channel."' OR channel = ''");
        $number_of_messages = $temp_db->loadResult();
  
        // If there is less then 10 results - set results number to 10 and query will load entries from 0 to 10.
        if ($number_of_messages < 10) {
            $number_of_messages = 10;
        }
        $temp_db->setQuery("SELECT n.nick, n.male, n.variable, n.datetime, n.type FROM #__cf_actions AS n WHERE n.channel = '".$channel."' OR channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10");
        $messages = $temp_db->loadObjectList();
  
        $temp_db->setQuery("SELECT topic FROM #__cf_channels WHERE name = '".$channel."'");
        $channel_topic = $temp_db->loadResult();

        $temp_db->setQuery("SELECT value FROM #__cf_settings WHERE name = 'bot_nick'");
        $bot_nick = $temp_db->loadResult();
  
        return $this->theme_cf_webchat_messages_area($bot_nick, $channel_topic, $messages);//2
    }
    
    //2
    function theme_cf_webchat_messages_area($bot_nick, $channel_topic, $messages) {
        global $webchat_options;
        $module_path = JURI::root().'components/com_webchat';
        $user        = & JFactory::getUser();
        if($webchat_options->sound == 1 ) $sound_state = true;
        else $sound_state = false;
        // If cookie is not set, then use variable from settings. Else - use cookie state.
        $is_notif_sound = empty($_COOKIE['cf_notification']) ? $sound_state : $this->cf_webchat_str_to_bool($_COOKIE['cf_notification']);//3
        $is_autohide_sm = empty($_COOKIE['cf_autohide']) ? TRUE : $this->cf_webchat_str_to_bool($_COOKIE['cf_autohide']);
  
        // Get connection state.
        $connection_state = 0;
        $text = "";
        if($webchat_options->ping == 1 ) $ping_op = true;
        else $ping_op = false;
        if ($ping_op) {
            $connection_state = $this->cf_webchat_get_connection_state();//4
            if ($connection_state == 1) {
                $css_class = "unstable_conn";
                $text = JText::_('CONNECTION_TO_THE_SERVER_IS_NOT_STABLE');
            }elseif ($connection_state == 2) {
                $css_class = "unactive_conn";
                $text = JText::_('CONNECTION_TO_THE_SERVER_IS_MISSING');
            }
        }
        $content = '<script type="text/javascript">
            function t(text){
                var trans = {
                        CONNECTION_TO_THE_SERVER_IS_NOT_STABLE  :   "'.JText::_('CONNECTION_TO_THE_SERVER_IS_NOT_STABLE').'", 
                        CONNECTION_TO_THE_SERVER_IS_MISSING     :   "'.JText::_('CONNECTION_TO_THE_SERVER_IS_MISSING').'",
                        STATE                                   :   "'.JText::_('STATE').'",
                        YOU_ARE_NOT_REGISTRED_IN_CHAT           :   "'.JText::_('YOU_ARE_NOT_REGISTRED_IN_CHAT').'",
                        ALREADY_IN_CHAT                         :   "'.JText::_('ALREADY_IN_CHAT').'",
                        WAITING_FOR_AUTHORIZATION               :   "'.JText::_('WAITING_FOR_AUTHORIZATION').'",
                        YOU_ARE_NOT_LOGGED_IN_ON_SAIT           :   "'.JText::_('YOU_ARE_NOT_LOGGED_IN_ON_SAIT').'",
                        TOO_MUCH_USERS_ONLINE                   :   "'.JText::_('TOO_MUCH_USERS_ONLINE').'",
                        NICK_IS_OUT_OF_RULES                    :   "'.JText::_('NICK_IS_OUT_OF_RULES').'",
                        YOU_ARE_BANNED                          :   "'.JText::_('YOU_ARE_BANNED').'",
                        NICK_INCLUDES_BAD_WORDS                 :   "'.JText::_('NICK_INCLUDES_BAD_WORDS').'",
                        NICK_IS_ALREADY_REGISTRED               :   "'.JText::_('NICK_IS_ALREADY_REGISTRED').'",
                        TOO_MUCH_USERS_FROM_IP                  :   "'.JText::_('TOO_MUCH_USERS_FROM_IP').'",
                        ACTIVATION_REQUEST_SENDED               :   "'.JText::_('ACTIVATION_REQUEST_SENDED').'",
                        WRONG_PASSWORD                          :   "'.JText::_('WRONG_PASSWORD').'",
                        ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS:   "'.JText::_('ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS').'",
                        CLICK_TO_CHANGE_STATE                   :   "'.JText::_('CLICK_TO_CHANGE_STATE').'",
                        HIDDEN                                  :   "'.JText::_('HIDDEN').'",
                        UNDEFINED                               :   "'.JText::_('UNDEFINED').'",
                        YOU_WRITE_NOTHING                       :   "'.JText::_('YOU_WRITE_NOTHING').'",
                        YOUR_MESSAGE_SUCCESFULLY_SENDED         :   "'.JText::_('YOUR_MESSAGE_SUCCESFULLY_SENDED').'",
                        THE_SIZE_OF_THE_TEXT                    :   "'.JText::_('THE_SIZE_OF_THE_TEXT').'"
                    }
                    for (var key in trans) {
                        if(key == text)
                            return trans[key];     
                    }
            }
        </script>';
        $content .='<script type="text/javascript" src="'.JURI::root().'components/com_webchat/assets/script.js"></script>';
        $content .= '
            <div class="connection_state' . (($connection_state != 0) ? ' ' . $css_class . '" style="display: block"' : '"') . ' title="' . JText::_('CONNECTION_STATE') . '">' . $text . '</div>
            <span class="channel_topic" title="' . JText::_('CHANNEL_THEME') . '">' . $channel_topic . '</span>
            <div id="messages_list">';
  
        foreach($messages as $message) {
            $content .= $this->theme_cf_webchat_message($message, FALSE, $bot_nick);//5
            $time = $message -> datetime;
        }
        $content .= '</div>';
        ob_start(); ?>
        <input type="hidden" value="<?php echo $time; ?>" id="last_msg_time" name="last_msg_time" />
        <?php if ($user->gid) : ?>
            <div id = "settings_block">
                <div class = "sound_opt" title="<?php echo JText::_('ENABLE_OR_DISABLE_SOUND_NOTIFICATION_WHEN_NEW_MESSAGE_IN_CHAT_RECIEVED'); ?>">
                    <input type = "checkbox" name="notif_sound" id="notif_sound"<?php echo ($is_notif_sound) ? ' checked="checked"' : ''; ?> onclick="notif_changed()" />
                    <label for= "notif_sound" ><?php echo JText::_('SOUND_NOTIFICATION'); ?></label>
                </div>
                <div class = "autohide_opt" title="<?php echo JText::_('ENABLE_OR_DISABLE_SMILIES_LIST_AUTOHIDE_WHEN_SMILE_ADDED_TO_MESSAGE_TEXT_AREA'); ?>">
                    <input type = "checkbox" name="autohide" id="autohide"<?php echo ($is_autohide_sm) ? ' checked="checked"' : ''; ?> onclick="autohide_changed()" />
                    <label for= "autohide" ><?php echo JText::_('AUTOHIDE_SMILIES'); ?></label>
                </div>
            </div>
            <div id = "smilies_block"><?php echo $this->cf_webchat_load_smilies_list();/* 9 */ ?></div>
            <table id="send_block">
                <tbody>
                    <tr class="send_row">
                        <td class="input_field"><textarea id="message" rows="1" cols="1" onkeypress="ctrlEnter(event, this);"></textarea></td>
                        <td class="addit_btns">
                            <img src="<?php echo $module_path; ?>/images/smilies.png" class="smilies_but" title="<?php echo JText::_('SHOW_SMILIES_LIST'); ?>" alt="<?php echo JText::_('SHOW_SMILIES_BLOCK'); ?>" />
                            <img src="<?php echo $module_path; ?>/images/settings.png" class="settings_but" title="<?php echo JText::_('SHOW_SETTINGS_BLOCK'); ?>" alt="<?php echo JText::_('SHOW_SETTINGS_BLOCK'); ?>" />
                            <img src="<?php echo $module_path; ?>/images/clear_chat.png" class="clear_but" title="<?php echo JText::_('CLEAR_CHAT'); ?>" alt="<?php echo JText::_('CLEAR_CHAT'); ?>" />
                        </td>
                        <td class="send_but">
                            <input id="send" type="button" value="<?php echo JText::_('SEND'); ?>" />        
                            <p><?php echo JText::_('OR'); ?> Ctrl+Enter</p>
                        </td>
                    </tr>
                    <tr>
                        <td><p class="send_state_text"></p></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>       
        <?php elseif(!$user->gid): ?>
        <div style="display:block;" id="settings_block"><?php echo JText::_('YOU_NOT_AUTHORIZED');?></div>
        <?php endif;
  
        $content .= ob_get_clean();
  
        return $content;
    }
    
    //3
    function cf_webchat_str_to_bool($string) {
        return ($string == 'false') ? false : true; 
    }
    
    //4
    function cf_webchat_get_connection_state() {
        global $options_op;
        $temp_db =& JDatabase::getInstance( $options_op );
        $temp_db->setQuery("SELECT value FROM #__cf_settings WHERE name = 'ping'");
        $ping_time = $temp_db->loadResult();   
        $interrupt_duration = time() - $ping_time;
          
        if ($interrupt_duration < 30) {
            $connection_state = 0;
        }elseif ($interrupt_duration > 30 && $interrupt_duration < 120) {
            $connection_state = 1;
        }elseif ($interrupt_duration >= 120) {
            $connection_state = 2;
        }
        return $connection_state;
    }
    
    //5
    function theme_cf_webchat_message($actions, $is_ajax, $bot_nick) {
        /*
            Messages type:
            0 - Simple Message
            1 - Message posted with status flag
            2 - User leaved the chat
            3 - User joined the chat
            4 - User joined the channel
            5 - User leaved the channel
            6 - User changed his/her state
            7 - User changed his/her icon of sex
            8 - User changed channel talk topic
        */
        global $webchat_options;
        if($webchat_options->smilies == 1 ) $smilies_op = true;
        else $smilies_op = false;
        if ($actions -> type == 0 || $actions -> type == 1 || $actions -> type == 6 || $actions -> type == 8) {
            $body = strip_tags($actions -> variable);
            if ($smilies_op) {
                $body = $this->cf_webchat_smilies_rep($body);//6
            }
            if ($actions -> type == 0 || $actions -> type == 1) {
                $body = $this->cf_webchat_spec_markup_rep($body);//7
                $is_from_web = ($actions -> nick == $bot_nick) ? TRUE : FALSE;
                if ($is_from_web) {
                    $pos = strpos($body, ':');
                    if (strpos($body, ':', $pos)) {
                        $actions -> nick = substr($body, 0, $pos);
                        $body = substr($body, $pos + 2, strlen($body) - $pos + 2);
                    }
                }
            }
        }
  
        if ($actions -> type != 6 && $actions -> type != 2) { 
            $nick = $this->theme_cf_webchat_nick($actions -> nick, $is_from_web, TRUE);//8
        }else {
            $nick = '<strong>' . $actions -> nick . '</strong>';
        }
        $msg_type = "single_message";
        if ($actions -> type == 1 || $actions -> type == 6 || $actions -> type == 8) {
            $msg_type = "single_system_message";
        }
    
        $message = '<div class="' . $msg_type . '"' . (($is_ajax) ? ' style="display: none;"' : '') . '>';
        $message .= ($actions -> type != 1) ? '<span class="msg_time">' . strftime('%H : %M : %S',$actions->datetime) . '</span>' : '';
        switch ($actions -> type) {
            case 0: case 1: 
                $message .= $nick . ': ' . $body;
                break;
            case 2:
                $message .=  ($actions -> male == 0) ? str_replace("!user_name",$nick,JText::_('MR_LEAVED_CHAT')) : str_replace("!user_name",$nick,JText::_('MS_LEAVED_CHAT'));
                break;
            case 3: 
                $message .= ($actions -> male == 0) ? str_replace("!user_name",$nick,JText::_('MR_JOINED_CHAT')) : str_replace("!user_name",$nick,JText::_('MS_JOINED_CHAT'));
                break;
            case 4: 
                $message .= ($actions -> male == 0) ? str_replace("!user_name",$nick,JText::_('MR_JOINED_CHANNEL')) : str_replace("!user_name",$nick,JText::_('MS_JOINED_CHANNEL'));
                break;
            case 5:
                $message .= ($actions -> male == 0) ? str_replace("!user_name",$nick,JText::_('MR_LEAVED_CHANNEL')) : str_replace("!user_name",$nick,JText::_('MS_LEAVED_CHANNEL'));
                break;
            case 6:
                $message .= $nick . ': ';
                if ($body != '')
                    $message .= (($actions -> male == 0) ? JText::_('CHANGED_HIS_STATE_TO') : JText::_('CHANGED_HER_STATE_TO')) . ' "' . $body . '"';
                else $message .= ($actions -> male == 0) ? JText::_('IS NOW ONLINE_MALE') : JText::_('IS_NOW_ONLIN_FEMALE');
                break;
            case 7:
                $message .= $nick . ': ' . (($actions -> male == 0) ? JText::_('CHANGED_HIS_SEX') : JText::_('CHANGED_HER_SEX')) . ' "' . (($actions -> variable == 0) ? JText::_('MALE') : JText::_('FEMALE')) . '"';
                break;
            case 8:
                $message .= $nick . ': ' . (($actions -> male == 0) ? JText::_('CHANGED_MALE_CHANNEL_THEME_TO') : JText::_('CHANGED_FEMALE_CHANNEL_THEME_TO')) . ' "' . $actions -> variable . '"';
                break;      
        }
  
        $message .= '</div>';
  
        return $message;
    }
    
    //6
    function cf_webchat_smilies_rep($body) {
        $optim_folder = JPATH_COMPONENT . DS . 'smilies/'; 
        if (file_exists($optim_folder . 'sm_paths.txt') && file_exists($optim_folder . 'sm_symbs.txt') && trim($body) != '') {
            $symbs_file = file($optim_folder . 'sm_symbs.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $paths_file = file($optim_folder . 'sm_paths.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $module_path = JURI::root().'components/com_webchat';
            for ($i = 0; $i < count($symbs_file); $i++) {
                $cur_smile = trim($symbs_file[$i]); 
                if ($cur_smile[0] != "#" && substr($cur_smile, 0, 2) != "#^") {
                    $pos = strpos($body, $cur_smile);      
                    while ($pos !== FALSE) {
                        $image = '<img src="' . $module_path . '/smilies/' . $paths_file[$i] . '" alt="'. JText::_('SMILE') .'" />';
                        $body = substr_replace($body, $image, $pos, strlen($cur_smile));
                        $offset = $pos + strlen($image);
                        $pos = strpos($body, $cur_smile, $offset);
                    }
                }
            }
        }
  
        return $body;
    }

    //7
    function cf_webchat_spec_markup_rep($body) {
        $patterns = array(
            '/\[url\=((http|https|ftp):\/\/[^\]]+)\]([^[]+)\[\/url\]/i',
            '/\[url\]((http|https|ftp):\/\/[^[]+)\[\/url\]/i',
            '/\[url\=([^[]+)\]([^[]+)\[\/url\]/i',
            '/\[url\]([^[]+)\[\/url\]/i',
            '/\[image\]/i',
            '/\\n/i',
        );
        $replaces = array(
            '<a href="\1" target="_blank" title="' . JText::_('OPEN_LINK_IN_NEW_WINDOW') . '">\3</a>',
            '<a href="\1" target="_blank" title="' . JText::_('OPEN_LINK_IN_NEW_WINDOW') . '">\1</a>',
            '\2',
            '\1',
            '[' . JText::_('USER_HAS_INSERTED_AN_IMAGE_IMAGES_ARE_NOT_SUPPORTED') . ']',
            '<br />',
        );
        $body = preg_replace($patterns, $replaces, $body);
  
        return $body;
    }
    
    //8
    function theme_cf_webchat_nick($name, $webicon, $title) {
        if ($title) {
            $title = ' title="' . (($webicon) ? JText::_('USER_FROM_WEB') . ". " : "") . JText::_('INSERT_NICK_IN_THE_POSTING_INPUT') . '"';
        }else {
            $title = '';
        }
        return '<a class="nick_paste' . (($webicon) ? " from_web" : "") . '"' . $title . ' onclick="insert_nick(this)">' . $name . '</a>';;
    }
    
    //9
    function cf_webchat_load_smilies_list() {
        $optim_folder = JPATH_COMPONENT . DS . 'smilies/';
        if (file_exists($optim_folder . 'sm_paths.txt') && file_exists($optim_folder . 'sm_symbs.txt')) {
            $symbs_file = file($optim_folder . 'sm_symbs.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $paths_file = file($optim_folder . 'sm_paths.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $module_path = JURI::root().'components/com_webchat';
            $smilies_list = "";
            $tab_list = "<p>";
            $c_count = 0;
            $skip_group = FALSE;
            $symb_count = count($symbs_file);
            for ($i = 0; $i < $symb_count; $i++) {
                $cur_line = $symbs_file[$i];
                if ($cur_line[0] == "#" && $cur_line[1] != "^") {
                    // Smilies are limited with two tabs. Too big page load. 
                    if ($c_count == 2) {
                        break;
                    }  
                    $tab_list .= '<span onclick="open_sm_tab(\'' . $c_count . '\')" title="' . JText::_('SHOW_SMILIES_IN_THIS_TAB') . '">' . substr($cur_line, 1) . "</span>&nbsp;";
                    if ($c_count != 0) {
                        $smilies_list .= '</div>';
                    }
                    $smilies_list .= '<div class="cf_sm_list">';
                    $c_count++; 
                    $skip_group = FALSE;
                }elseif ($cur_line[1] != "^" && !$skip_group) {
                    // We are escaping "\" symbols only in pop-up message.
                    $alt = str_replace("\"", "&quot;", $cur_line); 
                    $smilies_list .= '<img src="' . $module_path . '/smilies/' . $paths_file[$i] . '" alt="' . $alt . '" title="' . $alt . '" onclick="insert_smile(this)" />';  
                }else {
                    $skip_group = TRUE;
                }
            }
            $tab_list .= "</p>";
            $smilies_list .= '</div>';
        }
        return $tab_list . $smilies_list;
    }
    
    //10
    function cf_webchat_update() {
        global $webchat_options;
        global $options_op;
        $temp_db =& JDatabase::getInstance( $options_op );
        
        $last_msg_time      = JRequest::getVar('last_msg_time', '', 'post', 'int', JREQUEST_ALLOWRAW);
        $channel            = JRequest::getVar('channel', '', 'post', 'string', JREQUEST_ALLOWRAW);
        $connection_state   = JRequest::getVar('connection_state_v', '', 'post', 'int', JREQUEST_ALLOWRAW);
    
        if (isset($connection_state) && isset($last_msg_time) && isset($channel)) {
            $new_last_msg_time = $last_msg_time;
            $max_execution_time = ini_get('max_execution_time');
            if (isset($max_execution_time)) {
                $end_time = time() + $max_execution_time - 10;
            }else {
                $end_time = time() + 20;
            }      
      
            $is_new = FALSE;
            $new_connection_state = $connection_state;
            if($webchat_options->ping == 1 ) $ping_op = true;
            else $ping_op = false;
            $ping_check = $ping_op;
      
            // Check: if connection state changed (or this check disabled), new actions recieved or connection is ended.
            do {
                if ($last_msg_time == "0") {
                    $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions WHERE channel = '".$channel."' OR channel = ''");
                    $number_of_messages = $temp_db->loadResult();
                    if ($number_of_messages < 10) {
                        $number_of_messages = 10;
                    }
                    $query = db_query_range("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM {cf_actions} n WHERE n.channel = '%s' OR n.channel = '' ORDER BY n.datetime, n.id ASC", $channel, $number_of_messages-10, 10);
                    $temp_db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM #__cf_actions AS n 
                        WHERE n.channel = '".$channel."' OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10");
                    $query = $temp_db->loadObjectList();
                    
                    $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions AS n 
                        WHERE n.channel = '".$channel."' OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10");
                    $is_new = $temp_db->loadResult();
                }else {
                    $temp_db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM #__cf_actions AS n 
                        WHERE n.datetime > '".$last_msg_time."' AND (n.channel = '".$channel."' OR n.channel = '') ORDER BY n.datetime, n.id ASC");
                    $query = $temp_db->loadObjectList();
                    
                    $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions AS n 
                        WHERE n.datetime > '".$last_msg_time."' AND (n.channel = '".$channel."' OR n.channel = '')");
                    $is_new = $temp_db->loadResult();
                }
        
                if ($ping_check) {
                    $new_connection_state = $this->cf_webchat_get_connection_state();//4
                }
        
                // Free the CPU.
                sleep(1);
                clearstatcache();
            } while ((!$ping_check || $new_connection_state == $connection_state) && !$is_new && $end_time >= time());
      
            // If new actions appeared - add them to array;
            if ($is_new) {  
                $ready_mess = array();
                $temp_db->setQuery("SELECT value FROM #__cf_settings WHERE name = 'bot_nick'");
                $bot_nick = $temp_db->loadResult(); 
                foreach($query as $action_obj){
                    $ready_mess[] = $this->theme_cf_webchat_message($action_obj, TRUE, $bot_nick);//5
                    if ($action_obj -> type != 0 && $action_obj -> type != 1 && $action_obj -> type != 3 && $last_msg_time != "0") {
                        $actions[] = array(
                            'type' => $action_obj -> type, 
                            'variable' => $action_obj -> variable, 
                            'nick' => $action_obj -> nick, 
                            'male' => $action_obj -> male
                        );
                    }
                    $new_last_msg_time = $action_obj -> datetime;    
                }
            }
      
            $this->drupal_json(array('last_msg_time' => $new_last_msg_time, 'connection_state' => $new_connection_state, 'messages_array' => $ready_mess, 'actions_array' => $actions, 'user_auth' => $this->cf_webchat_get_auth_state()));  
      }
    }
    
    //11
    function cf_webchat_get_auth_state() {
        // Getting authorization states.
        $result = 0;
        $users   = & JFactory::getUser();
        global $options_op;
        $temp_db =& JDatabase::getInstance( $options_op );

        if ($users->get('gid')) {
            $temp_db->setQuery("SELECT auth, error FROM #__cf_web_users WHERE nick = '".$users->get('username')."'");
            $query_res = $temp_db->loadObject();

            if (empty($query_res)) {
                $password = explode(":",$users->get('password'));
                $temp_db->setQuery("INSERT INTO #__cf_web_users (nick, ip, pass, male, auth, error, ping) 
                    VALUES ('".$users->get('username')."', '".$this->getip()."', '".$password[1]."', '0', '0', '0', '".time()."')");                                                                           
                $temp_db->query();
                $result = 2;
            }else {
                $user_state = $query_res;
                if ($user_state->error == 0) {
                    $temp_db->setQuery("UPDATE #__cf_web_users SET `ping` = '".time()."' WHERE nick = '".$users->get('username')."'");                                                                           
                    $temp_db->query();
                    if ($user_state->auth == 0) { 
                        $result = 2;
                    } else {
                        $result = 1;
                    }
                }else {
                    $result = $user_state->error;
                }
            }      
        }else {
            $result = 3;
        }
        return $result;
    }
    
    //12
    function getip(){
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"),"unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        elseif (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        elseif (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        elseif (!empty($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return($ip);
    } 
    
    //13
    function drupal_json($var = NULL) {
        // We are returning JavaScript, so tell the browser.
        header('Content-Type: text/javascript; charset=utf-8');

        if (isset($var)) {
            echo $this->drupal_to_js($var);//13
        }
    }
    
    //14
    function drupal_to_js($var) {
        switch (gettype($var)) {
            case 'boolean':
                return $var ? 'true' : 'false'; // Lowercase necessary!
            case 'integer':
            case 'double':
                return $var;
            case 'resource':
            case 'string':
                return '"'. str_replace(array("\r", "\n", "<", ">", "&"),
                              array('\r', '\n', '\x3c', '\x3e', '\x26'),
                              addslashes($var)) .'"';
            case 'array':
                // Arrays in JSON can't be associative. If the array is empty or if it
                // has sequential whole number keys starting with 0, it's not associative
                // so we can go ahead and convert it as an array.
                if (empty ($var) || array_keys($var) === range(0, sizeof($var) - 1)) {
                    $output = array();
                    foreach ($var as $v) {
                        $output[] = $this->drupal_to_js($v);
                    }
                    return '[ '. implode(', ', $output) .' ]';
                }
                // Otherwise, fall through to convert the array as an object.
            case 'object':
                $output = array();
                foreach ($var as $k => $v) {
                    $output[] = $this->drupal_to_js(strval($k)) .': '. $this->drupal_to_js($v);
                }
                return '{ '. implode(', ', $output) .' }';
            default:
                return 'null';
        }
    }
    
    
    //15
    function cf_webchat_send_message() {  
        $body = JRequest::getVar('body', '', 'post', 'string', JREQUEST_ALLOWRAW);
        $channel = JRequest::getVar('channel', '', 'post', 'string', JREQUEST_ALLOWRAW);
        $connection_state = JRequest::getVar('connection_state_v', '', 'post', 'string', JREQUEST_ALLOWRAW);
        $users   = & JFactory::getUser();   
        global $options_op;
        $temp_db =& JDatabase::getInstance( $options_op );
        global $webchat_options;
    
        if (isset($connection_state) && isset($body) && isset($channel)) {
            $answer = 1;
            if (trim($body)) {
                if (strlen($body) <= 40000) {
                // If connection state is active - put message to cf_messages_to_send table. If unactive - put just to cf_actions table.
                    if($webchat_options->ping == 1 ) $ping_op = true;
                    else $ping_op = false; 
                    if ($webchat_options->ping == 0 || $connection_state != 2) {
                        $temp_db->setQuery("INSERT INTO #__cf_messages_to_send (`user`, `ip`, `channel`, `body`, `datetime`, `type`) 
                            VALUES('".$users->get('username')."', '".$this->getip()."', '".$channel."', '".$body."', '".time()."', '0')");                                                                           
                        $temp_db->query();
                    }else {
                        $temp_db->setQuery("INSERT INTO #__cf_actions (`variable`, `nick`, `male`, `channel`, `datetime`, `type`) 
                            VALUES('".$body."', '".$users->get('username')."', '0', '".$channel."', '".time()."', '0')");                                                                           
                        $temp_db->query();
                    }       
                }else {
                    $answer = 2;
                }
            } else {
                $answer = 0;
            }
            $this->drupal_json(array('answer' => $answer));      
        }    
    }
    
    
    
}