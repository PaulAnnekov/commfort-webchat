<?php

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controller');

class WebchatController extends JController
{
	function display() {
		parent::display();
	}
}