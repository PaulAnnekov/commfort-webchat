<?php
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.model' );


class WebchatModelWebchat extends JModel
{
    
    var $temp_db;
    
    function conect(){
       // if (empty( $this->temp_db ))
       // {
            $db =& JFactory::getDBO();
            $db->setQuery("SELECT * FROM #__webchat_options"); 
            $webchat_options = $db->loadObject();
            //conect to main server
            jimport('joomla.database.database');
            jimport( 'joomla.database.table' );
            $host_op = $webchat_options->host;
            $user_op = $webchat_options->user;
            $dbase_op = $webchat_options->database;
            $password_op = $webchat_options->password;
            $driver_op = $webchat_options->d_type;
            $prefix_op = $webchat_options->prefix;
        
            $options_op    = array ( 'driver' => $driver_op, 'host' => $host_op, 'user' => $user_op, 'password' => $password_op, 'database' => $dbase_op, 'prefix' => $prefix_op );

            $temp_db =& JDatabase::getInstance( $options_op );
        //}

        return $temp_db;
    }
    
    //get channel
    function getChannelExists($channel)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT name FROM #__cf_channels WHERE name = '".$channel."'");
        $channel_exists = $temp_db->loadResult(); 
        return $channel_exists;
    }
    //get first chabbel
    function getChannel()
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT name FROM #__cf_channels ORDER BY id ASC");
        $channel = $temp_db->loadResult(); 
        return $channel;
    }
    
    //Count of messages
    function getNumberMessage($channel)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions WHERE channel = '".$channel."' OR channel = ''");
        $number_of_messages = $temp_db->loadResult(); 
        return $number_of_messages;
    }
    
    //get last 10 Messages
    function getMessages($channel, $number_of_messages,$count)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT n.nick, n.male, n.variable, n.datetime, n.type FROM #__cf_actions AS n WHERE n.channel = '".$channel."' OR channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages).", ".$count."");
        $messages = $temp_db->loadObjectList(); 
        return $messages;
    }
    
    //get topic
    function getTopic($channel)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT topic FROM #__cf_channels WHERE name = '".$channel."'");
        $channel_topic = $temp_db->loadResult(); 
        return $channel_topic;
    }
    
    //get name of the bot
    function getBotnick()
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT value FROM #__cf_settings WHERE name = 'bot_nick'");
        $bot_nick = $temp_db->loadResult(); 
        return $bot_nick;
    }
    
    
    //get ping
    function getPingtime()
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT value FROM #__cf_settings WHERE name = 'ping'");
        $ping_time = $temp_db->loadResult(); 
        return $ping_time;
    }
    
    
    
    //Update message
    function getNewMessage1($channel, $number_of_messages,$count,$flag=null)
    {     
        $temp_db = $this->conect();
        if(is_null($flag) or $flag != "count"){
            $temp_db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM #__cf_actions AS n 
                WHERE n.channel = '".$channel."' OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages).", ".$count."");
            $query = $temp_db->loadObjectList(); 
        }elseif(!is_null($flag) or $flag == "count"){
            $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions AS n 
                WHERE n.channel = '".$channel."' OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages).", ".$count."");
            $query = $temp_db->loadResult();
        }
        return $query;
    }
    
    function getNewMessage2($channel, $last_msg_time,$flag=null)
    {     
        $temp_db = $this->conect();
        if(is_null($flag) or $flag != "count"){
            $temp_db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM #__cf_actions AS n 
                WHERE n.datetime > '".$last_msg_time."' AND (n.channel = '".$channel."' OR n.channel = '') ORDER BY n.datetime, n.id ASC");
            $query = $temp_db->loadObjectList(); 
        }elseif(!is_null($flag) or $flag == "count"){
            $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_actions AS n 
                WHERE n.datetime > '".$last_msg_time."' AND (n.channel = '".$channel."' OR n.channel = '')");
            $query = $temp_db->loadResult();
        }
        return $query;
    }
    
    //get Auth state
    function getAuthstate($user)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("SELECT auth, error FROM #__cf_web_users WHERE nick = '".$user."'");
        $query_res = $temp_db->loadObject(); 
        return $query_res;
    }
    
    //insert user info
    function insertuser($user,$ip,$pass)
    {     
        $temp_db = $this->conect();
        $password = explode(":",$pass);
        
        $temp_db->setQuery("INSERT INTO #__cf_web_users (nick, ip, pass, male, auth, error, ping) 
                    VALUES ('".$user."', '".$ip."', '".$password[1]."', '0', '0', '0', '".time()."')");                                                                           
        $temp_db->query(); 
        return true;
    }
    
    //insert user info
    function updatetuser($user)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("UPDATE #__cf_web_users SET `ping` = '".time()."' WHERE nick = '".$user."'");                                                                           
        $temp_db->query(); 
        return true;
    }
    
    //insert message
    function insermessage($user,$ip,$channel,$body,$time,$type)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("INSERT INTO #__cf_messages_to_send (user, ip, channel, body, datetime, type) 
                            VALUES('".$user."', '".$ip."', '".$channel."', '".$body."', '".$time."', '".$type."')");                                                                           
        $temp_db->query(); 
        return true;
    }
    
    //insert message
    function insermessage2($body, $user, $male, $channel, $time, $type)
    {     
        $temp_db = $this->conect();
        
        $temp_db->setQuery("INSERT INTO #__cf_actions (`variable`, `nick`, `male`, `channel`, `datetime`, `type`) 
                            VALUES('".$body."', '".$user."', '0', '".$channel."', '".$time."', '0')");                                                                           
        $temp_db->query(); 
        return true;
    }
    
}
