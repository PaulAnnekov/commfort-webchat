<?php
/**
 * Hellos View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


class WebchatsViewWebchats extends JView
{

	function display($tpl = null)
	{
		JToolBarHelper::title(   JText::_( 'WEBCHAT_MANAGER' ), 'generic.png' );
        
        JToolBarHelper::save();       

		// Get data from the model
		$items		= & $this->get( 'Data');
        
		$this->assignRef('items',		$items);

		parent::display($tpl);
	}
}