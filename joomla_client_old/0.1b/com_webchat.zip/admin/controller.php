<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class WebchatsController extends JController
{

	function display()
	{
		parent::display();
	}
    
    function save()
    {
        $model = $this->getModel('webchats');

        $post    = JRequest::get('post'); 
        
        if ($model->store($post)) {
            $msg = JText::_( 'OPTIONS_SAVED' );
        } else {
            $msg = JText::_( 'ERROR_SAVING_OPTIONS' );
        }

        // Check the table in so it can be edited.... we are done with it anyway
        $link = 'index.php?option=com_webchat';
        $this->setRedirect($link, $msg);
    }
    
    function optimize(){
        $sm_server =  JPATH_SITE . DS . 'components' . DS . 'com_webchat' . DS . 'smilies' . DS . 'smilies_serv.txt';
        if (file_exists($sm_server)) {
            $file = file($sm_server, FILE_SKIP_EMPTY_LINES);
            $line_offset = 0;
            while ($file[$line_offset][0] != '[') {
                $line_offset++; 
            }  
            $optim_folder = JPATH_SITE . DS . 'components' . DS . 'com_webchat' . DS . 'smilies';
            //file_check_directory($optim_folder, 1);
            $sm_paths = fopen($optim_folder . '/sm_paths.txt', "wb");
            $sm_symbs = fopen($optim_folder . '/sm_symbs.txt', "wb");
            for ($i = $line_offset; $i < count($file); $i++) {
                $line = trim($file[$i]);
                if ($line != '') {
                    if ($line[0] != '[') {
                        $path = str_replace("\\", "/", substr($line, 0, $pos)) . "\r\n";
                        $pos = strpos($line, '|');
                        $pos2 = strpos($line, '"', $pos);
                        $smile = substr($line, $pos2 + 1, strlen($line) - $pos2 - 2) . "\r\n";       
                        fwrite($sm_paths, $path);
                        fwrite($sm_symbs, $smile);
                    }else {
                        $pos = strpos($file[$i], ']');
                        $group = substr($file[$i], 1, $pos - 1);
                        ($group == "hidden") ? $group = '#^hidden' : $group = '#' . $group; 
                        $group .= "\r\n";
                        fwrite($sm_paths, $group);
                        fwrite($sm_symbs, $group);
                    }
                }  
            }
            fclose($sm_paths);
            fclose($sm_symbs);
            $msg = JText::_( 'SMILIES_SUCCESSFULLY_OPTIMIZED' );
        }else {
            $msg = str_replace("@foldername","cf_webchat/smilies/",JText::_( 'SMILIES_FILE_DOES_NOT_EXIST' ));
        }
        $link = 'index.php?option=com_webchat';
        $this->setRedirect($link, $msg);
    }
}