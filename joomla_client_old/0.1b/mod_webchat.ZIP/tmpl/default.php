<?php

defined('_JEXEC') or die('Restricted access');
       

$script = '<script type="text/javascript"> 
/*window.addEvent("domready",function(){
    var list = $$(".left_menu_special div");
    list.each(function(element,index) {
        $id = element.getProperty("id");
        if($id == "labels" && list[index-0+1].getProperty("class") == "line")
            list[index-0+1].setStyle("display", "none");
    }); 
});*/
</script>';

//DISPLAY RESULT 
echo /*$script.*/$web; 