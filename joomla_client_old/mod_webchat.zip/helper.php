<?php
defined('_JEXEC') or die('Restricted access'); 

class modWebchatHelper
{
    function buildchat($params){
        $this->paramss =  $params;

        $db =& JFactory::getDBO();
        $db->setQuery("SELECT * FROM #__webchat_options");  
        $this->options = $db->loadObject();
        
        if($this->options->native_db == 1){
            $this->db =& JFactory::getDBO();        
        }else{
            //conect to main server
            jimport('joomla.database.database');
            jimport( 'joomla.database.table' );
            $this->host_op      = $this->options->host;
            $this->user_op      = $this->options->user;
            $this->dbase_op     = $this->options->database;
            $this->password_op  = $this->options->password;
            $this->driver_op    = $this->options->d_type;
            $this->prefix_op    = empty($this->options->prefix) ? 'tmp' : $this->options->prefix;
            $options_op = array (
                'driver'    => $this->driver_op, 
                'host'      => $this->host_op, 
                'user'      => $this->user_op, 
                'password'  => $this->password_op, 
                'database'  => $this->dbase_op, 
                'prefix'    => $this->prefix_op 
            );    
            $this->db =& JDatabase::getInstance( $options_op );
        }
        if($this->prefix_op == 'tmp'){
            $this->prefix_op = '';
        }else{
            $this->prefix_op = '#__';
        }

        $chat = self::cf_webchat_block_users_content();
        return $chat; 
    }
    
    //1
    function cf_webchat_block_users_content() { 
        $user       = & JFactory::getUser(); 
        $document   =& JFactory::getDocument();
        $document->addStyleSheet( JURI::root().'modules/mod_webchat/css/style.css', 'text/css' );
         
        $show_ips = $this->paramss->get('showIp');
        $this->db->setQuery("SELECT n.id, n.nick, n.male, n.ip, n.state FROM ".$this->prefix_op."cf_users_online AS n ORDER BY n.nick ASC");
        $accounts = $this->db->loadObjectList();
        
        $this->db->setQuery("SELECT COUNT(*) FROM ".$this->prefix_op."cf_users_online");
        $online_users = $this->db->loadResult();
        
        $this->db->setQuery("SELECT name FROM ".$this->prefix_op."cf_channels ORDER BY id ASC");
        $channels = $this->db->loadObjectList();
        
        (empty($_COOKIE['cf_channel'])) ? $a_channel = 'main' : $a_channel = rawurldecode($_COOKIE['cf_channel']); 
        $auth_state = self::cf_webchat_get_auth_state();//2
        $auth_loc_array = self::_cf_webchat_auth_states();//3
        $alt = JText::_('STATE');
        $tip = $auth_loc_array[$auth_state];
        if ($auth_state == 0 || $auth_state > 3) {
            $img = "error";
        } elseif ($auth_state == 2) {
            $img = "wait";
        } else {
            $img = "ok";
            $alt = $auth_loc_array['1'];
            $tip = JText::_('CLICK_TO_CHANGE_STATE');
        }
        
        $options = array(
            'channels'      => $channels,
            'a_channel'     => $a_channel,
            'user'          => $user,
            'img'           => $img,
            'alt'           => $alt,
            'tip'           => $tip,
            'module_path'   => JURI::root() . 'modules/mod_webchat',
            'online_users'  => $online_users, 
            'accounts'      => $accounts, 
            'show_ips'      => $show_ips
        );
        
        //$content = ($user->get('gid')) ? self::theme_cf_webchat_user_block($options) : '';//4 
        //$content .= self::theme_cf_webchat_users_online($online_users, $accounts, $show_ips);//5

        return $options;   
    }
    
    //2
    function cf_webchat_get_auth_state() {
        // Getting authorization states.
        $result = 0;
        $users   = & JFactory::getUser();

        if ($users->get('gid')) {
            $this->db->setQuery("SELECT auth, error FROM ".$this->prefix_op."cf_web_users WHERE nick = ".$this->db->quote($users->get('username')));
            $query_res = $this->db->loadObject();

            if (empty($query_res)) {
                $password = explode(":",$users->get('password'));
                $this->db->setQuery("INSERT INTO ".$this->prefix_op."cf_web_users (nick, ip, pass, male, auth, error, ping) 
                    VALUES (
                        ".$this->db->quote($users->get('username')).", 
                        ".$this->db->quote(self::getip()).", 
                        ".$this->db->quote($password[1]).", 
                        '0', 
                        '0', 
                        '0', 
                        '".time()."'
                    )");                                                                           
                $this->db->query();
                $result = 2;
            }else {
                $user_state = $query_res;
                if ($user_state->error == 0) {
                    $this->db->setQuery("UPDATE ".$this->prefix_op."cf_web_users SET `ping` = '".time()."' WHERE nick = ".$this->db->quote($users->get('username')));                                                                           
                    $this->db->query();
                    if ($user_state->auth == 0) { 
                        $result = 2;
                    } else {
                        $result = 1;
                    }
                }else {
                    $result = $user_state->error;
                }
            }      
        }else {
            $result = 3;
        }
        return $result; 
    }
    
    //3
    function _cf_webchat_auth_states() {
        // User authirization states.
        $auth_array = array(
            JText::_('YOU_ARE_NOT_REGISTRED_IN_CHAT'),
            JText::_('ALREADY_IN_CHAT'),
            JText::_('WAITING_FOR_AUTHORIZATION'),
            JText::_('YOU_ARE_NOT_LOGGED_IN_ON_SAIT'),
            JText::_('TOO_MUCH_USERS_ONLINE'),
            JText::_('NICK_IS_OUT_OF_RULES'),
            JText::_('YOU_ARE_BANNED'),
            JText::_('NICK_INCLUDES_BAD_WORDS'),
            JText::_('NICK_IS_ALREADY_REGISTRED'),
            JText::_('TOO_MUCH_USERS_FROM_IP'),
            JText::_('ACTIVATION_REQUEST_SENDED'),
            JText::_('WRONG_PASSWORD'),
            JText::_('ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS'),
        );
        return $auth_array;
    }
    
    //4
    function theme_cf_webchat_nick($name, $webicon, $title) {
        if ($title) {
            $title = ' title="' . (($webicon) ? JText::_('USER_FROM_WEB') . ". " : "") . JText::_('INSERT_NICK_IN_THE_POSTING_INPUT') . '"';
        }else {
            $title = '';
        }
        return '<a class="nick_paste' . (($webicon) ? " from_web" : "") . '"' . $title . '>' . $name . '</a>';;
    }
    
    function getip(){
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"),"unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        elseif (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        elseif (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        elseif (!empty($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "N/A";
        return($ip);
    }

}