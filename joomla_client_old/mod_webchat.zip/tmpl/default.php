<?php
defined('_JEXEC') or die('Restricted access');
//DISPLAY RESULT
$user   = & JFactory::getUser();
if($user->get('gid')) {
?>
<div id="curr_user">
    <!--<span class="name man"><?php //echo theme('username', $user); ?></span>-->
    <span class="name man" style="background: url('<?php echo $options['module_path']?>/images/man_icon.png') no-repeat scroll 0 0 transparent !important"><?php echo $options['user']->get('username'); ?></span>
    <div class="channel">
        <select name="channel" id="channel" onchange="reload_channel()">
            <?php foreach($options['channels'] as $channel) { ?>
            <option<?php echo ($options['a_channel'] == $channel->name) ?  " selected" : ""; ?>><?php echo $channel->name; ?></option>
            <?php }; ?>
        </select>
    </div>
    <div class="state"><img src="<?php echo $options['module_path']; ?>/images/stat_<?php echo $options['img']; ?>.png" alt="<?php echo $options['alt']; ?>" title="<?php echo $options['alt']; ?>" /><span><?php echo $options['tip']; ?></span></div>
</div> 
<?php } ?>
<div id="users_list">
    <div class="all_users_count"><strong><?php echo JText::_('USERS_ONLINE') . ":"; ?></strong> <?php echo $online_users; ?>.</div>
    <ul id="listusers">
        <?php foreach($options['accounts'] as $account) { ?>
        <li class="single_user <?php echo ($account -> male == 1) ? 'woman' : 'man'; ?>">
            <?php echo modWebchatHelper::theme_cf_webchat_nick($account->nick, FALSE, FALSE); /*6*/?>
            <div class="user_info" >
                IP: <?php echo ((bool)$options['show_ips'] && $account->ip != 'N/A') ? $account->ip : JText::_('HIDDEN'); ?><br />
                <?php echo JText::_('STATE') . ":"; ?> <?php echo ($account->state != '') ? $account->state : JText::_('UNDEFINED'); ?>
            </div>
        </li>
        <?php }; ?>
    </ul>
</div>