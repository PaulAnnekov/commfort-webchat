<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php'); 

$params->def('chattype', 'defaultwebchat');
$params->def('showIp', '');
//$params->def('class_sfx', 	'');

$options = modWebchatHelper::buildchat($params);
require(JModuleHelper::getLayoutPath('mod_webchat'));