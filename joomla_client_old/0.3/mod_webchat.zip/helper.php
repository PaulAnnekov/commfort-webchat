<?php
defined('_JEXEC') or die('Restricted access'); 

class modWebchatHelper
{
    function buildchat($params){
        global $paramss;
        $paramss =  $params;

        $db =& JFactory::getDBO();
        $db->setQuery("SELECT * FROM #__webchat_options");
        global $webchat_options;
        $webchat_options = $db->loadObject();
        if($webchat_options->native_db == 0){
            //conect to main server 
            jimport('joomla.database.database');
            jimport( 'joomla.database.table' );
            $host_op = $webchat_options->host;
            $user_op = $webchat_options->user;
            $dbase_op = $webchat_options->database;
            $password_op = $webchat_options->password;
            $driver_op = $webchat_options->d_type;
            $prefix_op = $webchat_options->prefix;
            global $options_op;
            $options_op    = array ( 'driver' => $driver_op, 'host' => $host_op, 'user' => $user_op, 'password' => $password_op, 'database' => $dbase_op, 'prefix' => $prefix_op );       
        }elseif($webchat_options->native_db == 0){
            global $options_op;
            $options_op = "native_db";    
        }

        $chat = modWebchatHelper::cf_webchat_block_users_content();
        return $chat; 
    }

    //1
    function cf_webchat_block_users_content() {
        global $paramss;
        global $options_op;
        if($options_op != "native_db")
            $temp_db =& JDatabase::getInstance( $options_op );
        else
            $temp_db =& JFactory::getDBO();
        global $webchat_options;

        $user   = & JFactory::getUser(); 
        $document =& JFactory::getDocument();
        $document->addStyleSheet( JURI::root().'modules/mod_webchat/css/style.css', 'text/css' );

        $show_ips = $paramss->get('showIp');
        $temp_db->setQuery("SELECT n.id, n.nick, n.male, n.ip, n.state FROM #__cf_users_online AS n ORDER BY n.nick ASC");
        $accounts = $temp_db->loadObjectList();

        $temp_db->setQuery("SELECT COUNT(*) FROM #__cf_users_online");
        $online_users = $temp_db->loadResult();

        $temp_db->setQuery("SELECT name FROM #__cf_channels ORDER BY id ASC");
        $channels = $temp_db->loadObjectList();

        (empty($_COOKIE['cf_channel'])) ? $a_channel = 'main' : $a_channel = rawurldecode($_COOKIE['cf_channel']);
        $auth_state = modWebchatHelper::cf_webchat_get_auth_state();//2
        $auth_loc_array = modWebchatHelper::_cf_webchat_auth_states();//3
        $alt = JText::_('STATE');
        $tip = $auth_loc_array[$auth_state];
        if ($auth_state == 0 || $auth_state > 3) {
            $img = "error";
        } elseif ($auth_state == 2) {
            $img = "wait";
        } else {
            $img = "ok";
            $alt = $auth_loc_array['1'];
            $tip = JText::_('CLICK_TO_CHANGE_STATE');
        }
        
        $options = array(
            'channels'  => $channels,
            'a_channel' => $a_channel,
            'user'      => $user,
            'img'       => $img,
            'alt'       => $alt,
            'tip'       => $tip,
        );

        $content = ($user->get('gid')) ? modWebchatHelper::theme_cf_webchat_user_block($options) : '';//4 
        $content .= modWebchatHelper::theme_cf_webchat_users_online($online_users, $accounts, $show_ips);//5

        return $content;
    }

    //2
    function cf_webchat_get_auth_state() {
        // Getting authorization states.
        $result = 0;
        $users   = & JFactory::getUser();
        global $options_op;
        if($options_op != "native_db")
            $temp_db =& JDatabase::getInstance( $options_op );
        else
            $temp_db =& JFactory::getDBO();

        if ($users->get('gid')) {
            $temp_db->setQuery("SELECT auth, error FROM #__cf_web_users WHERE nick = '".$users->get('username')."'");
            $query_res = $temp_db->loadObject();

            if (empty($query_res)) {
                $password = explode(":",$users->get('password'));
                $temp_db->setQuery("INSERT INTO #__cf_web_users (nick, ip, pass, male, auth, error, ping) 
                    VALUES ('".$users->get('username')."', '".modWebchatHelper::getip()."', '".$password[1]."', '0', '0', '0', '".time()."')");                                                                           
                $temp_db->query();
                $result = 2;
            }else {
                $user_state = $query_res;
                if ($user_state->error == 0) {
                    $temp_db->setQuery("UPDATE #__cf_web_users SET `ping` = '".time()."' WHERE nick = '".$users->get('username')."'");                                                                           
                    $temp_db->query();
                    if ($user_state->auth == 0) { 
                        $result = 2;
                    } else {
                        $result = 1;
                    }
                }else {
                    $result = $user_state->error;
                }
            }      
        }else {
            $result = 3;
        }
        return $result;
    }

    //3
    function _cf_webchat_auth_states() {
        // User authirization states.
        $auth_array = array(
            JText::_('YOU_ARE_NOT_REGISTRED_IN_CHAT'),
            JText::_('ALREADY_IN_CHAT'),
            JText::_('WAITING_FOR_AUTHORIZATION'),
            JText::_('YOU_ARE_NOT_LOGGED_IN_ON_SAIT'),
            JText::_('TOO_MUCH_USERS_ONLINE'),
            JText::_('NICK_IS_OUT_OF_RULES'),
            JText::_('YOU_ARE_BANNED'),
            JText::_('NICK_INCLUDES_BAD_WORDS'),
            JText::_('NICK_IS_ALREADY_REGISTRED'),
            JText::_('TOO_MUCH_USERS_FROM_IP'),
            JText::_('ACTIVATION_REQUEST_SENDED'),
            JText::_('WRONG_PASSWORD'),
            JText::_('ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS'),
        );
        return $auth_array;
    }

    //4
    function theme_cf_webchat_user_block($options) {
        //$user   = & JFactory::getUser();
        $module_path = JURI::root() . 'modules/mod_webchat';;

        ob_start(); ?>
        <div id="curr_user">
            <!--<span class="name man"><?php //echo theme('username', $user); ?></span>-->
            <span class="name man" style="background: url('<?=$module_path?>/images/man_icon.png') no-repeat scroll 0 0 transparent !important"><?php echo $options['user']->get('username'); ?></span>
            <div class="channel">
                <select name="channel" id="channel" onchange="reload_channel()">
                    <?php foreach($options['channels'] as $channel) { ?>
                    <option<?php echo ($options['a_channel'] == $channel->name) ?  " selected" : ""; ?>><?php echo $channel->name; ?></option>
                    <?php }; ?>
                </select>
            </div>
            <div class="state"><img src="<?php echo $module_path; ?>/images/stat_<?php echo $options['img']; ?>.png" alt="<?php echo $options['alt']; ?>" title="<?php echo $options['alt']; ?>" /><span><?php echo $options['tip']; ?></span></div>
        </div><?php
        
        return ob_get_clean();
    }

    //5
    function theme_cf_webchat_users_online($online_users, $accounts, $show_ips) {
        ob_start(); ?>
        <div id="users_list">
            <div class="all_users_count"><strong><?php echo JText::_('USERS_ONLINE') . ":"; ?></strong> <?php echo $online_users; ?>.</div>
            <ul id="listusers">
                <?php foreach($accounts as $account) { ?>
                <li class="single_user <?php echo ($account -> male == 1) ? 'woman' : 'man'; ?>">
                    <?php echo modWebchatHelper::theme_cf_webchat_nick($account -> nick, FALSE, FALSE); /*6*/?>
                    <div class="user_info" >
                    IP: <?php echo ($show_ips && $account -> ip != 'N/A') ? $account -> ip : JText::_('HIDDEN'); ?><br />
                    <?php echo JText::_('STATE') . ":"; ?> <?php echo ($account -> state != '') ? $account -> state : JText::_('UNDEFINED'); ?>
                    </div>
                </li>
                <?php }; ?>
            </ul>
        </div>
        <?
        return ob_get_clean();
    }

    //6
    function theme_cf_webchat_nick($name, $webicon, $title) {
        if ($title) {
            $title = ' title="' . (($webicon) ? JText::_('USER_FROM_WEB') . ". " : "") . JText::_('INSERT_NICK_IN_THE_POSTING_INPUT') . '"';
        }else {
            $title = '';
        }
        return '<a class="nick_paste' . (($webicon) ? " from_web" : "") . '"' . $title . ' onclick="insert_nick(this)">' . $name . '</a>';;
    }

    function getip(){
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"),"unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        elseif (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        elseif (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        elseif (!empty($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return($ip);
    }

}