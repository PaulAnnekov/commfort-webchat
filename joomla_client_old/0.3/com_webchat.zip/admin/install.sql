DROP TABLE IF EXISTS `#__webchat_options`;

CREATE TABLE `#__webchat_options` (
  `id` int(11) NOT NULL auto_increment,
  `host` varchar(250) character set utf8 collate utf8_unicode_ci NOT NULL,
  `user` varchar(250) character set utf8 collate utf8_unicode_ci default NULL,
  `password` varchar(250) character set utf8 collate utf8_unicode_ci default NULL,
  `database` varchar(250) character set utf8 collate utf8_unicode_ci default NULL,
  `prefix` varchar(10) character set utf8 collate utf8_unicode_ci default NULL,
  `d_type` varchar(10) character set utf8 collate utf8_unicode_ci default NULL,
  `ip` smallint(1) default NULL,
  `smilies` smallint(1) default NULL,
  `sound` smallint(1) default NULL,
  `ping` smallint(1) default NULL,
  `native_db` smallint(6) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

insert  into `#__webchat_options`(`id`,`host`,`user`,`password`,`database`,`prefix`,`d_type`,`ip`,`smilies`,`sound`,`ping`,`native_db`) values ('1','localhost','user_name','pass','bd_name','jos_','mysql','1','1','1','1','0');

