<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

class WebchatsViewWebchats extends JView
{
	function display($tpl = null)
	{
		JToolBarHelper::title(   JText::_( 'WEBCHAT_MANAGER' ), 'generic.png' );
        JToolBarHelper::save();       
		// Get data from the model
		$items		= & $this->get( 'Data');
		$this->assignRef('items',		$items);
		parent::display($tpl);
	}
}