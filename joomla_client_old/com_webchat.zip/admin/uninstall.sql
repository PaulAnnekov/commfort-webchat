DROP TABLE IF EXISTS `#__webchat_options`;
