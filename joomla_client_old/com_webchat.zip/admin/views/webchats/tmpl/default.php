<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<?php $row = &$this->items; ?>
<div>
    <table style="width:100%;">
        <tr>
            <td style="width:150px;font-size:14px;font-weight:bold;"><?php echo JText::_( 'CHECK_NATIVE_DB' ); ?>:</td>
            <td style="width:230px;"><input type="checkbox" id="check_native_db" name="check_native_db" value="1" <?php if($row->native_db == 1) echo 'checked="checked"'; ?> /></td>
            <td><?php echo JText::_( 'CHECK_NATIVE_DB_DESCK' ); ?></td>
            <script type="text/javascript">
                window.addEvent('domready', function(){
                    if($('check_native_db').getProperty("checked") == true){
                        $$('.db_remote').each(function(el,ind){
                            el.getElement("input").setStyles({"text-decoration":"line-through","font-style":"italic","color":"#cccccc"});
                        })
                    }
                    $('check_native_db').addEvent("click",function(){
                        if($('check_native_db').getProperty("checked") == true){
                            $$('.db_remote').each(function(el,ind){
                                //el.getElement("input").setStyle("display","none");
                                el.getElement("input").setStyles({"text-decoration":"line-through","font-style":"italic","color":"#cccccc"});
                            })
                        }else{
                            $$('.db_remote').each(function(el,ind){
                                el.getElement("input").setStyles({"text-decoration":"none","font-style":"normal","color":"black"});
                            })
                        }
                    })
                });
            </script>
        </tr>
        <tr>
            <td style="width:150px;font-size:14px;font-weight:bold;"><?php echo JText::_( 'HOST' ); ?>:</td>
            <td style="width:230px;" class="db_remote"><input style="width:200px;" id="host" name="host" type="text" value="<?php echo $row->host; ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td style="width:150px;font-size:14px;font-weight:bold;"><?php echo JText::_( 'USER' ); ?>:</td>
            <td style="width:230px;" class="db_remote"><input style="width:200px;" id="user" name="user" type="text" value="<?php echo $row->user; ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( 'PASSWORD' ); ?>:</td>
            <td class="db_remote"><input style="width:200px;" id="password" name="password" type="text" value="<?php echo $row->password; ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( 'DATABASE' ); ?>:</td>
            <td class="db_remote"><input style="width:200px;" id="database" name="database" type="text" value="<?php echo $row->database; ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( 'DATABASE_PREFIX' ); ?>:</td>
            <td class="db_remote"><input style="width:200px;" id="prefix" name="prefix" type="text" value="<?php echo $row->prefix; ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( 'DATABASE_TYPE' ); ?>:</td>
            <td class="db_remote"><input style="width:200px;" id="driver" name="driver" type="text" value="<?php echo $row->d_type; ?>" /></td>
            <td>mysql, mysqli, postgresql, ...</td>
        </tr>
        <tr><td colspan="3">&nbsp;</td></tr>
        <tr><td colspan="3" style="text-align:center;"><b><?php echo JText::_( 'CHAT' ); ?></b></td></tr>
        <!--<tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( "SHOW_USERS_IP" ); ?>:</td>
            <td><input type="checkbox" name="cf_webchat_show_ips" value="1" <?php if($row->ip == 1) echo 'checked="checked"'; ?> checked="checked" /></td>
            <td><?php echo JText::_( "CHECK_IF_IPS_MUST_BE_SHOWN_IN_USERS_BLOCK" ); ?></td>
        </tr>-->
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( "ENABLE_SMILIES" ); ?>:</td>
            <td><input type="checkbox" name="cf_webchat_smilies_enabled" value="1" <?php if($row->smilies == 1) echo 'checked="checked"'; ?> /></td>
            <td><?php echo str_replace("!foldername","/components/com_webchat/smilies",str_replace("!filename","smilies_serv.txt", JText::_('SMILIES_HAVE_LOCATED_ENCODING_UTF8' ))); ?></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( "ENABLE_SOUND_NOTIFICATION" ); ?>:</td>
            <td><input type="checkbox" name="cf_webchat_def_sound_state" value="1" <?php if($row->sound == 1) echo 'checked="checked"'; ?> /></td>
            <td><?php echo JText::_( "CHECK_SOUND_NOTIFICATION_EVENT" ); ?></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( "ENABLE_CHECKING_PING_FROM_PLUGIN" ); ?>:</td>
            <td><input type="checkbox" name="cf_webchat_ping_check" value="1" <?php if($row->ping == 1) echo 'checked="checked"'; ?> /></td>
            <td><?php echo JText::_( "CHECK_SYNCHRONIZED" ); ?></td>
        </tr>
        <tr>
            <td style="font-size:14px;font-weight:bold;"><?php echo JText::_( "OPTIMIZE_SMILIES" ); ?>:</td>
            <td><input type="button" onclick="javascript: submitbutton('optimize')" name="cf_webchat_optimize_smilies_submit" value="<?php echo JText::_( "OPTIMIZE_SMILIES" ); ?>" /></td>
            <td></td>
        </tr>
    </table>
</div>
<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
<input type="hidden" name="option" value="com_webchat" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="webchat" />
</form>