<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class WebchatsModelWebchats extends JModel
{
	var $_data;

	function getData()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data )){
			$db =& JFactory::getDBO();
            $query = 'SELECT * FROM #__webchat_options';
            $db->setQuery( $query );
			$this->_data = $db->loadObject();
		}
		return $this->_data;
	}
    
    function store($data){    
        $db =& JFactory::getDBO();
        $query = 'UPDATE #__webchat_options 
            SET 
                `host` = "'.$data['host'].'", 
                `user` = "'.$data['user'].'", 
                `password` = "'.$data['password'].'", 
                `database` = "'.$data['database'].'", 
                `prefix` = "'.$data['prefix'].'", 
                `d_type` = "'.$data['driver'].'", 
                `ip` = "'.$data['cf_webchat_show_ips'].'", 
                `smilies` = "'.$data['cf_webchat_smilies_enabled'].'", 
                `sound` = "'.$data['cf_webchat_def_sound_state'].'", 
                `ping` = "'.$data['cf_webchat_ping_check'].'",              
                `native_db` = "'.$data['check_native_db'].'" 
            WHERE id = "'.$data['id'].'"';
            $db->setQuery( $query );
            if (!$db->query()) {
                $this->setError($db->getErrorMsg());
                return false;
            }
        return true;
    }
}