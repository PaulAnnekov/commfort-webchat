<?php
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.model' );

class WebchatModelWebchat extends JModel
{
    //var $temp_db;

    function __construct(){
        parent::__construct();
        
        $db =& JFactory::getDBO();
        $db->setQuery("SELECT * FROM #__webchat_options");  
        $this->options = $db->loadObject();
        
        if($this->options->native_db == 1){
            $this->db =& JFactory::getDBO();        
        }else{
            //conect to main server
            jimport('joomla.database.database');
            jimport( 'joomla.database.table' );
            $this->host_op      = $this->options->host;
            $this->user_op      = $this->options->user;
            $this->dbase_op     = $this->options->database;
            $this->password_op  = $this->options->password;
            $this->driver_op    = $this->options->d_type;
            $this->prefix_op    = empty($this->options->prefix) ? 'tmp' : $this->options->prefix;
            $options_op = array (
                'driver'    => $this->driver_op, 
                'host'      => $this->host_op, 
                'user'      => $this->user_op, 
                'password'  => $this->password_op, 
                'database'  => $this->dbase_op, 
                'prefix'    => $this->prefix_op 
            );    
            $this->db =& JDatabase::getInstance( $options_op );
        }
        if($this->prefix_op == 'tmp'){
            $this->prefix_op = '';
        }else{
            $this->prefix_op = '#__';
        }  
    }
    
    function cf_webchat_block_messages_content($channel = '',$cf_notification = '',$cf_autohide = '') {
        $channel = (empty($_COOKIE['cf_channel'])) ? '' : rawurldecode($_COOKIE['cf_channel']);   
        if ($channel != '') {
            $this->db->setQuery("SELECT name FROM ".$this->prefix_op."cf_channels WHERE name = ".$this->db->quote($channel));
            $channel_exists = $this->db->loadResult();
        }
        if (!$channel_exists || $channel == '') {
            $this->db->setQuery("SELECT name FROM ".$this->prefix_op."cf_channels ORDER BY id ASC");
            $channel = $this->db->loadResult();
        }

        $this->db->setQuery("SELECT COUNT(*) FROM ".$this->prefix_op."cf_actions WHERE channel = ".$this->db->quote($channel)." OR channel = ''");
        $number_of_messages = $this->db->loadResult();
        // If there is less then 10 results - set results number to 10 and query will load entries from 0 to 10.
        if ($number_of_messages < 10) {
            $number_of_messages = 10;
        }
        $this->db->setQuery("
            SELECT n.nick, n.male, n.variable, n.datetime, n.type 
            FROM ".$this->prefix_op."cf_actions AS n 
            WHERE n.channel = ".$this->db->quote($channel)." OR channel = '' 
            ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10
        ");
        $messages = $this->db->loadObjectList();

        $this->db->setQuery("SELECT topic FROM ".$this->prefix_op."cf_channels WHERE name = ".$this->db->quote($channel));
        $channel_topic = $this->db->loadResult();

        $this->db->setQuery("SELECT value FROM ".$this->prefix_op."cf_settings WHERE name = 'bot_nick'");
        $bot_nick = $this->db->loadResult();
        
        // If cookie is not set, then use variable from settings. Else - use cookie state.    
        $is_notif_sound = empty($_COOKIE['cf_notification']) ? (bool)$this->options->sound : $this->cf_webchat_str_to_bool($_COOKIE['cf_notification']);//2
        $is_autohide_sm = empty($_COOKIE['cf_autohide']) ? TRUE : $this->cf_webchat_str_to_bool($_COOKIE['cf_autohide']);//2
        
        // Get connection state.
        $connection_state = 0;
        $text = "";

        if ((bool)$this->options->ping) {
            $connection_state = $this->cf_webchat_get_connection_state();//3
            if ($connection_state == 1) {
                $css_class = "unstable_conn";
                $text = JText::_('CONNECTION_TO_THE_SERVER_IS_NOT_STABLE');
            }elseif ($connection_state == 2) {
                $css_class = "unactive_conn";
                $text = JText::_('CONNECTION_TO_THE_SERVER_IS_MISSING');
            }
        }
  
        $options = array(
            'con_state'     => $connection_state,
            'state_text'    => $text,
            'state_class'   => $css_class,
            //'module_path'   => $module_path,    
            'sound'         => $is_notif_sound,
            'autohide'      => $is_autohide_sm,
            'bot_nick'      => $bot_nick, 
            'channel_topic' => $channel_topic, 
            'messages'      => $messages 
        ); 

        return $options;
    }
    
    //2
    function cf_webchat_str_to_bool($string) {
        return ($string == 'false') ? false : true; 
    }
    
    //3
    function cf_webchat_get_connection_state() {
        $this->db->setQuery("SELECT value FROM ".$this->prefix_op."cf_settings WHERE name = 'ping'");
        $ping_time = $this->db->loadResult();   
        $interrupt_duration = time() - $ping_time;

        if ($interrupt_duration < 30) {
            $connection_state = 0;
        }elseif ($interrupt_duration > 30 && $interrupt_duration < 120) {
            $connection_state = 1;
        }elseif ($interrupt_duration >= 120) {
            $connection_state = 2;
        }
        return $connection_state;
    }
    
    //4
    function theme_cf_webchat_message($actions, $is_ajax, $bot_nick) {
        /*
            Messages type:
            0 - Simple Message
            1 - Message posted with status flag
            2 - User leaved the chat
            3 - User joined the chat
            4 - User joined the channel
            5 - User leaved the channel
            6 - User changed his/her state
            7 - User changed his/her icon of sex
            8 - User changed channel talk topic
        */
        $m_text = '';
        $m_type = $actions->type;
        // If message shows that user leaved chat ot channel then we disallow replies.
        // Message types 2 or 5.
        if ($m_type == 2 || $m_type == 5) { 
            $nick = '<strong>' . $actions->nick . '</strong>'; 
        }else {
            $nick = $this->theme_cf_webchat_nick($actions->nick, $is_from_web, TRUE);//5
        }
        
        // If message type implies availability of HTML tags, smiles or CommFort BBcode. 
        // Body of these messages is edited by users(id's: 0, 1, 6, 8).
        if (in_array($m_type, array(0, 1, 6, 8))) {
            $body = strip_tags($actions->variable);
            if ((bool)$this->options->smilies) {
                $body = $this->cf_webchat_smilies_rep($body);//6
            }
        }
        
        // If it is users messages then we must replace CommFort BBCode and check if it is
        // unlogged web user. Message types 0 or 1. Else we format this message as system message.
        if ($m_type == 0 || $m_type == 1) {
            $body = $this->cf_webchat_spec_markup_rep($body);//7 
            $is_from_web = ($actions->nick == $bot_nick) ? TRUE : FALSE;
      
            if ($is_from_web) {
                $pos = strpos($body, ':');
                if (strpos($body, ':', $pos)) {
                    $actions->nick = substr($body, 0, $pos);
                    $body = substr($body, $pos + 2, strlen($body) - $pos + 2);
                }
            }     

            $m_text .= $nick . ': ' . $body;
            $msg_class = "single_message";
        }else {
            $m_text .= str_replace("!user_name",$nick,JText::_('USER')) . ' ' . $this->cf_webchat_t_messages($m_type, $body, $actions->variable);//8            
            $msg_class = "single_system_message";
        }
        
        $message = 
            '<div class="' . $msg_class . '"' . (($is_ajax) ? ' style="display: none;"' : '') . '>
                <span class="msg_time">' . strftime('%H : %M : %S',$actions->datetime) . '</span>
                ' . $m_text . '
            </div>';
  
        return $message;
    }
    
    //5
    function theme_cf_webchat_nick($name, $webicon, $title) {
        if ($title) {
            $title = ' title="' . (($webicon) ? JText::_('USER_FROM_WEB') . ". " : "") . JText::_('INSERT_NICK_IN_THE_POSTING_INPUT') . '"';
        }else {
            $title = '';
        }
        return '<a class="nick_paste' . (($webicon) ? " from_web" : "") . '"' . $title . ' onclick="insert_nick(this)">' . $name . '</a>';;
    }
    
    //6
    function cf_webchat_smilies_rep($body) {
        $optim_folder = JPATH_COMPONENT . DS . 'smilies/'; 
        if (file_exists($optim_folder . 'sm_paths.txt') && file_exists($optim_folder . 'sm_symbs.txt') && trim($body) != '') {
            $symbs_file = file($optim_folder . 'sm_symbs.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $paths_file = file($optim_folder . 'sm_paths.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $module_path = JURI::root().'components/com_webchat';
            for ($i = 0; $i < count($symbs_file); $i++) {
                $cur_smile = trim($symbs_file[$i]); 
                if ($cur_smile[0] != "#" && substr($cur_smile, 0, 2) != "#^") {
                    $pos = strpos($body, $cur_smile);      
                    while ($pos !== FALSE) {
                        // We can't add text representation of smile in alt ot title, because it may be replaced
                        // by next smile search.
                        $image = '<img src="' . $module_path . '/smilies/' . $paths_file[$i] . '" alt="'. JText::_('SMILE') .'" />';
                        $body = substr_replace($body, $image, $pos, strlen($cur_smile));
                        $offset = $pos + strlen($image);
                        $pos = strpos($body, $cur_smile, $offset);
                    }
                }
            }
        }

        return $body;
    }
    
    //7
    function cf_webchat_spec_markup_rep($body) {
        $patterns = array(
            '/\[url\=((http|https|ftp):\/\/[^\]]+)\]([^[]+)\[\/url\]/i',
            '/\[url\]((http|https|ftp):\/\/[^[]+)\[\/url\]/i',
            '/\[url\=([^[]+)\]([^[]+)\[\/url\]/i',
            '/\[url\]([^[]+)\[\/url\]/i',
            '/\[image\]/i',
            '/\\n/i',
        );
        $replaces = array(
            '<a href="\1" target="_blank" title="' . JText::_('OPEN_LINK_IN_NEW_WINDOW') . '">\3</a>',
            '<a href="\1" target="_blank" title="' . JText::_('OPEN_LINK_IN_NEW_WINDOW') . '">\1</a>',
            '\2',
            '\1',
            '[' . JText::_('USER_HAS_INSERTED_AN_IMAGE_IMAGES_ARE_NOT_SUPPORTED') . ']',
            '<br />',
        );
        $body = preg_replace($patterns, $replaces, $body);

        return $body;
    }
    
    //8
    function cf_webchat_t_messages($id, $body, $var) {
        $messages = array(
            JText::_('LEAVED_THE_CHAT'),
            JText::_('JOINED_THE_CHAT'),
            JText::_('JOINED_THE_CHANNEL'),
            JText::_('LEAVED_THE_CHANNEL'),    
        );
        if (in_array($id, array(2, 3, 4, 5))) {
            $t_message = $messages[$id-2];
        } else {
            switch($id) {
                case 6:
                    $t_message = ($body != '') ? JText::_('SWITCHED_TO_STATE') . ' "' . $body . '"' : JText::_('IS_NOW_ONLINE'); 
                    break;     
                case 7:
                    $t_message = JText::_('CHANGED_SEX_TO') . ' "' . (($var == 0) ? JText::_('MALE') : JText::_('FEMALE')) . '"';
                    break;      
                case 8:
                    $t_message = JText::_('CHANGED_CHANNEL_THEME_TO') . ' "' . $var . '"';
            }    
        }
        return $t_message;
    }
    
    //9
    function cf_webchat_load_smilies_list() {
        $optim_folder = JPATH_COMPONENT . DS . 'smilies/';
        if (file_exists($optim_folder . 'sm_paths.txt') && file_exists($optim_folder . 'sm_symbs.txt')) {
            $symbs_file = file($optim_folder . 'sm_symbs.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $paths_file = file($optim_folder . 'sm_paths.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $module_path = JURI::root().'components/com_webchat';
            $smilies_list = "";
            $tab_list = "<p>";
            $c_count = 0;
            $skip_group = FALSE;
            $symb_count = count($symbs_file);
            for ($i = 0; $i < $symb_count; $i++) {
                $cur_line = $symbs_file[$i];
                if ($cur_line[0] == "#" && $cur_line[1] != "^") {
                    // Smilies are limited with two tabs. Too big page load. 
                    if ($c_count == 2) {
                        break;
                    }  
                    $tab_list .= '<span class="sm_tab" title="' . JText::_('SHOW_SMILIES_IN_THIS_TAB') . '">' . substr($cur_line, 1) . "</span>&nbsp;";
                    if ($c_count != 0) {
                        $smilies_list .= '</div>';
                    }
                    $smilies_list .= '<div class="cf_sm_list">';
                    $c_count++; 
                    $skip_group = FALSE;
                }elseif ($cur_line[1] != "^" && !$skip_group) {
                    // We are escaping "\" symbols only in pop-up message.
                    $alt = str_replace("\"", "&quot;", $cur_line); 
                    $smilies_list .= '<img src="' . $module_path . '/smilies/' . $paths_file[$i] . '" alt="' . $alt . '" title="' . $alt . '" class="cf_smile" />';  
                }else {
                    $skip_group = TRUE;
                }
            }
            $tab_list .= "</p>";
            $smilies_list .= '</div>';
        }
        return $tab_list . $smilies_list;
    }
    
    //10 update
    function cf_webchat_update() {
        $last_msg_time      = JRequest::getVar('last_msg_time', '', 'get', 'int', JREQUEST_ALLOWRAW);
        $channel            = JRequest::getVar('channel', '', 'get', 'string', JREQUEST_ALLOWRAW);
        $connection_state   = JRequest::getVar('connection_state_v', '', 'get', 'int', JREQUEST_ALLOWRAW);

        if (isset($connection_state) && isset($last_msg_time) && isset($channel)) {
            $new_last_msg_time = $last_msg_time;
            $max_execution_time = ini_get('max_execution_time');
            if (isset($max_execution_time)) {
                $end_time = time() + $max_execution_time - 10;
            }else {
                $end_time = time() + 20;
            }      
      
            $is_new = FALSE;
            $new_connection_state = $connection_state;

            // Check: if connection state changed (or this check disabled), new actions recieved or connection is ended.
            do {
                if ($last_msg_time == "0") {
                    $this->db->setQuery("SELECT COUNT(*) FROM ".$this->prefix_op."cf_actions WHERE channel = ".$this->db->quote($channel)." OR channel = ''");
                    $number_of_messages = $this->db->loadResult();
                    if ($number_of_messages < 10) {
                        $number_of_messages = 10;
                    }
                    $this->db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM ".$this->prefix_op."cf_actions AS n 
                        WHERE n.channel = ".$this->db->quote($channel)." OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10");
                    $query = $this->db->loadObjectList();

                    $this->db->setQuery("SELECT COUNT(*) FROM ".$this->prefix_op."cf_actions AS n 
                        WHERE n.channel = ".$this->db->quote($channel)." OR n.channel = '' ORDER BY n.datetime, n.id ASC LIMIT ".($number_of_messages-10).", 10");
                    $is_new = $this->db->loadResult();
                }else {
                    $this->db->setQuery("SELECT n.variable, n.nick, n.male, n.datetime, n.type FROM ".$this->prefix_op."cf_actions AS n 
                        WHERE n.datetime > ".$this->db->quote($last_msg_time)." AND (n.channel = ".$this->db->quote($channel)." OR n.channel = '') ORDER BY n.datetime, n.id ASC");
                    $query = $this->db->loadObjectList();

                    $this->db->setQuery("SELECT COUNT(*) FROM ".$this->prefix_op."cf_actions AS n 
                        WHERE n.datetime > ".$this->db->quote($last_msg_time)." AND (n.channel = ".$this->db->quote($channel)." OR n.channel = '')");
                    $is_new = $this->db->loadResult();
                }

                if ((bool)$this->options->ping) {
                    $new_connection_state = $this->cf_webchat_get_connection_state();//3
                }
                // Free the CPU.
                sleep(1);
                clearstatcache();
            } while ((!$ping_check || $new_connection_state == $connection_state) && !$is_new && $end_time >= time());

            // If new actions appeared - add them to array;
            if ($is_new) {  
                $ready_mess = array();
                $this->db->setQuery("SELECT value FROM ".$this->prefix_op."cf_settings WHERE name = 'bot_nick'");
                $bot_nick = $this->db->loadResult(); 
                foreach($query as $action_obj){
                    $ready_mess[] = $this->theme_cf_webchat_message($action_obj, TRUE, $bot_nick);//4
                    if ($action_obj->type != 0 && $action_obj->type != 1 && $action_obj->type != 3 && $last_msg_time != "0") {
                        $actions[] = array(
                            'type'      => $action_obj->type, 
                            'variable'  => $action_obj->variable, 
                            'nick'      => $action_obj->nick, 
                            'male'      => $action_obj->male
                        );
                    }
                    $new_last_msg_time = $action_obj->datetime;    
                }
            }

            $this->drupal_json(array('last_msg_time' => $new_last_msg_time, 'connection_state' => $new_connection_state, 'messages_array' => $ready_mess, 'actions_array' => $actions, 'user_auth' => $this->cf_webchat_get_auth_state())); //11 , 13
      }
    }
    
    //11
    function cf_webchat_get_auth_state() {
        // Getting authorization states.
        $result = 0;
        $users   = & JFactory::getUser();
        if ($users->get('gid')) {
            $this->db->setQuery("SELECT auth, error FROM ".$this->prefix_op."cf_web_users WHERE nick = ".$this->db->quote($users->get('username')));
            $query_res = $this->db->loadObject();

            if (empty($query_res)) {
                $password = explode(":",$users->get('password'));
                $this->db->setQuery("INSERT INTO ".$this->prefix_op."cf_web_users (nick, ip, pass, male, auth, error, ping) 
                    VALUES (".$this->db->quote($users->get('username')).", ".$this->db->quote($this->getip()).", ".$this->db->quote($password[1]).", '0', '0', '0', '".time()."')");                                                                           
                $this->db->query();
                $result = 2;
            }else {
                $user_state = $query_res;
                if ($user_state->error == 0) {
                    $this->db->setQuery("UPDATE ".$this->prefix_op."cf_web_users SET `ping` = '".time()."' WHERE nick = ".$this->db->quote($users->get('username')));                                                                           
                    $this->db->query();
                    if ($user_state->auth == 0) { 
                        $result = 2;
                    } else {
                        $result = 1;
                    }
                }else {
                    $result = $user_state->error;
                }
            }      
        }else {
            $result = 3;
        }
        return $result;
    }
    
    //12
    function getip(){
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"),"unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        elseif (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        elseif (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        elseif (!empty($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return($ip);
    } 
    
    //13
    function drupal_json($var = NULL) {
        // We are returning JavaScript, so tell the browser.
        header('Content-Type: text/javascript; charset=utf-8');
        if (isset($var)) {
            echo $this->drupal_to_js($var);//13
        }
    }
    
    //14
    function drupal_to_js($var) {
        switch (gettype($var)) {
            case 'boolean':
                return $var ? 'true' : 'false'; // Lowercase necessary!
            case 'integer':
            case 'double':
                return $var;
            case 'resource':
            case 'string':
                return '"'. str_replace(array("\r", "\n", "<", ">", "&"),
                              array('\r', '\n', '\x3c', '\x3e', '\x26'),
                              addslashes($var)) .'"';
            case 'array':
                // Arrays in JSON can't be associative. If the array is empty or if it
                // has sequential whole number keys starting with 0, it's not associative
                // so we can go ahead and convert it as an array.
                if (empty ($var) || array_keys($var) === range(0, sizeof($var) - 1)) {
                    $output = array();
                    foreach ($var as $v) {
                        $output[] = $this->drupal_to_js($v);
                    }
                    return '[ '. implode(', ', $output) .' ]';
                }
                // Otherwise, fall through to convert the array as an object.
            case 'object':
                $output = array();
                foreach ($var as $k => $v) {
                    $output[] = $this->drupal_to_js(strval($k)) .': '. $this->drupal_to_js($v);
                }
                return '{ '. implode(', ', $output) .' }';
            default:
                return 'null';
        }
    } 
 
    //15 send message
    function cf_webchat_send_message() {  
        $body               = JRequest::getVar('body', '', 'get', 'string', JREQUEST_ALLOWRAW);
        $channel            = JRequest::getVar('channel', '', 'get', 'string', JREQUEST_ALLOWRAW);
        $connection_state   = JRequest::getVar('connection_state_v', '', 'get', 'string', JREQUEST_ALLOWRAW);
        $users   = & JFactory::getUser();   

        if (isset($connection_state) && isset($body) && isset($channel)) {
            $answer = 1;
            if (trim($body)) {
                if (strlen($body) <= 40000) {
                // If connection state is active - put message to cf_messages_to_send table. If unactive - put just to cf_actions table.
                    if ($this->options->ping == 0 || $connection_state != 2) {
                        $this->db->setQuery("INSERT INTO ".$this->prefix_op."cf_messages_to_send (`user`, `ip`, `channel`, `body`, `datetime`, `type`) 
                            VALUES(
                                ".$this->db->quote($users->get('username')).", 
                                ".$this->db->quote($this->getip()).", 
                                ".$this->db->quote($channel).", 
                                ".$this->db->quote($body).", 
                                '".time()."', 
                                '0'
                            )");                                                                           
                        $this->db->query();
                    }else {
                        $this->db->setQuery("INSERT INTO ".$this->prefix_op."cf_actions (`variable`, `nick`, `male`, `channel`, `datetime`, `type`) 
                            VALUES(
                                ".$this->db->quote($body).", 
                                ".$this->db->quote($users->get('username')).", 
                                '0', 
                                ".$this->db->quote($channel).", 
                                '".time()."', 
                                '0'
                            )");                                                                           
                        $this->db->query();
                    }       
                }else {
                    $answer = 2;
                }
            } else {
                $answer = 0;
            }
            $this->drupal_json(array('answer' => $answer));//13      
        }    
    }
}