<?php
defined( '_JEXEC' ) or die();
jimport( 'joomla.application.component.view' );
class WebchatViewWebchat extends JView
{
    function display($tpl = null) {
        $model = &$this->getModel();
        
        $cf_update = JRequest::getVar('cf_update', null);
        $cf_add = JRequest::getVar('cf_add', null);
        if($cf_update == 1 and $cf_update != null){
            $chat = $model->cf_webchat_update();//10
            exit;
        }elseif($cf_add == 1 and $cf_add != null){
            $chat = $model->cf_webchat_send_message();//15
            exit;    
        }
        
        $document =& JFactory::getDocument();
        JHTML::_('behavior.mootools');
        $document->addStyleSheet( JURI::root().'components/com_webchat/assets/style.css', 'text/css' );
        $document->addScriptDeclaration('
            function t(text){
                var trans = {
                        CONNECTION_TO_THE_SERVER_IS_NOT_STABLE  :   "'.JText::_('CONNECTION_TO_THE_SERVER_IS_NOT_STABLE').'", 
                        CONNECTION_TO_THE_SERVER_IS_MISSING     :   "'.JText::_('CONNECTION_TO_THE_SERVER_IS_MISSING').'",
                        STATE                                   :   "'.JText::_('STATE').'",
                        YOU_ARE_NOT_REGISTRED_IN_CHAT           :   "'.JText::_('YOU_ARE_NOT_REGISTRED_IN_CHAT').'",
                        ALREADY_IN_CHAT                         :   "'.JText::_('ALREADY_IN_CHAT').'",
                        WAITING_FOR_AUTHORIZATION               :   "'.JText::_('WAITING_FOR_AUTHORIZATION').'",
                        YOU_ARE_NOT_LOGGED_IN_ON_SAIT           :   "'.JText::_('YOU_ARE_NOT_LOGGED_IN_ON_SAIT').'",
                        TOO_MUCH_USERS_ONLINE                   :   "'.JText::_('TOO_MUCH_USERS_ONLINE').'",
                        NICK_IS_OUT_OF_RULES                    :   "'.JText::_('NICK_IS_OUT_OF_RULES').'",
                        YOU_ARE_BANNED                          :   "'.JText::_('YOU_ARE_BANNED').'",
                        NICK_INCLUDES_BAD_WORDS                 :   "'.JText::_('NICK_INCLUDES_BAD_WORDS').'",
                        NICK_IS_ALREADY_REGISTRED               :   "'.JText::_('NICK_IS_ALREADY_REGISTRED').'",
                        TOO_MUCH_USERS_FROM_IP                  :   "'.JText::_('TOO_MUCH_USERS_FROM_IP').'",
                        ACTIVATION_REQUEST_SENDED               :   "'.JText::_('ACTIVATION_REQUEST_SENDED').'",
                        WRONG_PASSWORD                          :   "'.JText::_('WRONG_PASSWORD').'",
                        ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS:   "'.JText::_('ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS').'",
                        CLICK_TO_CHANGE_STATE                   :   "'.JText::_('CLICK_TO_CHANGE_STATE').'",
                        HIDDEN                                  :   "'.JText::_('HIDDEN').'",
                        UNDEFINED                               :   "'.JText::_('UNDEFINED').'",
                        YOU_WRITE_NOTHING                       :   "'.JText::_('YOU_WRITE_NOTHING').'",
                        YOUR_MESSAGE_SUCCESFULLY_SENDED         :   "'.JText::_('YOUR_MESSAGE_SUCCESFULLY_SENDED').'",
                        THE_SIZE_OF_THE_TEXT                    :   "'.JText::_('THE_SIZE_OF_THE_TEXT').'",
                        URL                                     :   "'.JURI::root().'"
                    }
                    for (var key in trans) {
                        if(key == text)
                            return trans[key];     
                    }
            }
        ');
        $document->addScript(JURI::root().'components/com_webchat/assets/script.js');
        
        //'module_path'   => $module_path // from $options
        $component_path = JURI::root().'components/com_webchat';
        
        //options
        $options = $model->cf_webchat_block_messages_content($channel,$cf_notification,$cf_autohide);
            
        //messages
        foreach($options['messages'] as $message){
            $content .= $model->theme_cf_webchat_message($message, FALSE, $options['bot_nick']);//4
            $time = $message->datetime;
        }
            
        //smilies
        $smilies = $model->cf_webchat_load_smilies_list();
        
        $this->assignRef('component_path',  $component_path);
        $this->assignRef('options',         $options);
        $this->assignRef('content',         $content);
        $this->assignRef('time',            $time);
        $this->assignRef('smilies',         $smilies);
        
        parent::display($tpl);
    }


}