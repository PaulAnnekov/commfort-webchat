<?php
defined('_JEXEC') or die('Restricted access');
$user = & JFactory::getUser();

?>

<div class="connection_state <?php if($this->options['con_state'] != 0) echo $this->options['state_class'] . '" style="display: block'; ?>" title="<?php echo JText::_('CONNECTION_STATE');?>"><?php echo $this->options['state_text'];?></div>
    <span class="channel_topic" title="<?php echo JText::_('CHANNEL_THEME');?>"><?php echo $this->options['channel_topic']; ?></span>
    <div id="messages_list"><?php echo $this->content ;?></div>
<input type="hidden" value="<?php echo $this->time; ?>" id="last_msg_time" name="last_msg_time" />
<?php if ($user->gid) : ?>
    <div id = "settings_block">
        <div class="sound_opt" title="<?php echo JText::_('ENABLE_OR_DISABLE_SOUND_NOTIFICATION_WHEN_NEW_MESSAGE_IN_CHAT_RECIEVED'); ?>">
            <input type="checkbox" name="notif_sound" id="notif_sound"<?php echo ($this->options['sound']) ? ' checked="checked"' : ''; ?> />
            <label for="notif_sound"><?php echo JText::_('SOUND_NOTIFICATION'); ?></label>
        </div>
        <div class="autohide_opt" title="<?php echo JText::_('ENABLE_OR_DISABLE_SMILIES_LIST_AUTOHIDE_WHEN_SMILE_ADDED_TO_MESSAGE_TEXT_AREA'); ?>">
            <input type="checkbox" name="autohide" id="autohide"<?php echo ($this->options['autohide']) ? ' checked="checked"' : ''; ?> />
            <label for="autohide" ><?php echo JText::_('AUTOHIDE_SMILIES'); ?></label>
        </div>
    </div>
    <div id = "smilies_block"><?php echo $this->smilies; ?></div>
    <table id="send_block">
        <tbody>
            <tr class="send_row">
                <td class="input_field"><textarea id="message" rows="1" cols="1"></textarea></td>
                <td class="addit_btns">
                    <img src="<?php echo $this->component_path; ?>/images/smilies.png" class="smilies_but" title="<?php echo JText::_('SHOW_SMILIES_LIST'); ?>" alt="<?php echo JText::_('SHOW_SMILIES_BLOCK'); ?>" />
                    <img src="<?php echo $this->component_path; ?>/images/settings.png" class="settings_but" title="<?php echo JText::_('SHOW_SETTINGS_BLOCK'); ?>" alt="<?php echo JText::_('SHOW_SETTINGS_BLOCK'); ?>" />
                    <img src="<?php echo $this->component_path; ?>/images/clear_chat.png" class="clear_but" title="<?php echo JText::_('CLEAR_CHAT'); ?>" alt="<?php echo JText::_('CLEAR_CHAT'); ?>" />
                </td>
                <td class="send_but">
                    <input id="send" type="button" value="<?php echo JText::_('SEND'); ?>" />        
                    <p><?php echo JText::_('OR'); ?> Ctrl+Enter</p>
                </td>
            </tr>
            <tr>
                <td><p class="send_state_text"></p></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>       
<?php elseif(!$user->gid): ?>
    <div style="display:block;" id="settings_block"><?php echo JText::_('YOU_NOT_AUTHORIZED');?></div>
<?php endif;