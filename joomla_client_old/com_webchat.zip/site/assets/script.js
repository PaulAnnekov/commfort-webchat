// $Id$
var soundEmbed = null;
var is_notif_needed = true;
var autohide = true;
var xhr = null;
var last_active_sm_list;
var connection_state = 0;

window.addEvent('domready', function(){
    if ($("notif_sound") && $("notif_sound").getProperty("checked") == false)
        is_notif_needed = false;
    if ($("autohide") && $("autohide").getProperty("checked") == false)
        autohide = false; 

    if($("send")){
    $("send").addEvent("click",function() {
        var id;
        if ($('message').getProperty("value").trim() == "")
            id = 0;
        else if ($('message').getProperty("value").length > 40000)
            id = 2;
        if (id != undefined)
            send_report(id);
        else {
            $("send").setProperty('disabled', 'disabled');
            $("message").setProperty('disabled', 'disabled');
            
            var url ="index.php?option=com_webchat&view=webchat&cf_add=1&body="+$("message").getProperty("value")+"&channel="+$('channel').getValue()+"&connection_state_v="+connection_state;
            var s = new Ajax( url, {
                method: 'get',
                onComplete: function(data) {
                    var result = eval("(" + data + ")");
                    $("send").setProperty('disabled', '');
                    $("message").setProperty('disabled', '');       
                    send_report(result.answer);
                }
            }).request();
        }
    });
    }
    
    if($("channel")){
        $("channel").addEvent("change",function() {
            reload_channel();
        });
    }
    
    $$(".nick_paste").each(function(el,ind){
        el.addEvent("click",function(){
            insert_nick(this);
        })
    })
    
    $$(".cf_smile").each(function(el,ind){
        el.addEvent("click",function(){
            insert_smile(this);
        })
    })
    
    if($("notif_sound")){
        $("notif_sound").addEvent("click",function() {
            notif_changed();
        });
    }
    
    if($("autohide")){
        $("autohide").addEvent("click",function() {
            autohide_changed();
        });
    }
    
    $$(".settings_but").each(function(elem,ind){
        elem.addEvent("click",function() {
            if ($("settings_block").getStyle("display") != "none")
                $("settings_block").setStyle("display", "none");
            else $("settings_block").setStyle("display", "block");
        });
    })
    
    $$(".smilies_but").each(function(elem,ind){
        elem.addEvent("click",function() {
            if ($("smilies_block").getStyle("display") != "none") {
                open_sm_tab(last_active_sm_list);
                $("smilies_block").setStyle("display", "none");    
            }else {
                $("smilies_block").setStyle("display", "block"); 
                open_sm_tab(0);
            }
        })
    });
    $$(".clear_but").each(function(elem,ind){
        elem.addEvent("click",function() {
            var e_count = $("messages_list").getElements("div").length;
            if (e_count > 10) {
                e_count -= 11;
                for (var i = 0; i <= e_count; i++) {
                    $("messages_list").getFirst().remove();
                }
            }
        });
    });
    
    if($("message")){
        $("message").addEvent("keypress",function(event) {
            ctrlEnter(event);
        });
    }
  
    $$(".sm_tab").each(function(el,ind){
        el.addEvent("click",function(){
            open_sm_tab(ind);
        })
    })

    setTimeout('load_messages()',  1000);
});

function open_sm_tab(id) {
    if (last_active_sm_list != undefined) {
        $("smilies_block").getElements("div")[last_active_sm_list].setStyle("display", "none");
        $("smilies_block").getElement("p").getElements("span")[last_active_sm_list].setStyle("border-bottom", "none");
    }
    if (last_active_sm_list != id) {
        $("smilies_block").getElements("div")[id].setStyle("display", "block");
        $("smilies_block").getElement("p").getElements("span")[id].setStyle("border-bottom", "1px solid #AFAFAF");
        last_active_sm_list = id;
    }
    else last_active_sm_list = null; 
}

function play_notif(){
    /*if (soundEmbed) {
        document.body.removeChild(soundEmbed);
        soundEmbed.removed = true;
        soundEmbed = null;
    }

    soundEmbed = document.createElement("embed");
    soundEmbed.setAttribute("src", "/components/com_webchat/sounds/new_mess.mp3");
    soundEmbed.setAttribute("hidden", true);
    soundEmbed.setAttribute("autostart", true);
    soundEmbed.removed = false;
    document.body.appendChild(soundEmbed);*/
    var sound_path = t('URL')+"components/com_webchat/sounds/new_mess.mp3";
    if (soundEmbed) {
        soundEmbed.remove();
        soundEmbed = null;
    }
    //soundEmbed = $('<embed></embed>').attr({src: sound_path, autostart: true, hidden: true});
    var soundEmbed = new Element('embed', {
        'src': sound_path,
        'autostart': 'true',
        'hidden':'true'
    });
    //$('body').append(soundEmbed);
    document.body.appendChild(soundEmbed);
}

function is_nick_higher(current_nick, new_nick) {
    var i = 0;
    var is_higher = false;
    var nn_len = new_nick.length;

    //if current_nick[i] == null (current_nick smaller then new_nick) then new_nick will be above current_nick
    while (i < nn_len && current_nick[i] != null) {
        var cur_nn_sym = new_nick[i].toLowerCase();
        var cur_cn_sym = current_nick[i].toLowerCase();

        if (cur_nn_sym != cur_cn_sym) {
            //alert("cur_nn_sym != cur_cn_sym");
            if (cur_nn_sym > cur_cn_sym) 
                is_higher = false;
            else if (cur_nn_sym < cur_cn_sym)
                is_higher = true;
            break;
        }
        i++;
    }
    return is_higher;
}

function notif_changed() {
    if ($("notif_sound").getProperty("checked") == true)
          is_notif_needed = true;
    else is_notif_needed = false;
    setcookie("cf_notification", is_notif_needed);
}

function autohide_changed() {
    if ($("autohide").getProperty("checked") == true)
          autohide = true;
    else autohide = false;
    setcookie("cf_autohide", autohide);
}

function ctrlEnter(event, formElem) {
  if((event.ctrlKey) && ((event.keyCode == 0xA)||(event.keyCode == 0xD))){
    document.getElementById('send').click();
  }
}

function setcookie(name, value) {
    // Set "Expires" time to one week.
    var expires = new Date();
    expires.setTime(expires.getTime() + (1000 * 21600 * 24 * 7));
    document.cookie = name + "=" + value + ";" + 
                      "expires=" + expires.toGMTString() + ";";
}

function reload_channel() {
  //xhr.abort();
  setcookie("cf_channel", encodeURIComponent($('channel').getValue()));
  window.location.reload();
}

function insert_nick(obj) {
  var nick = obj.innerHTML + '> ';
  $('message').setProperty("value",$('message').getProperty('value') + nick);
  $('message').focus();
}

function insert_smile(obj) {
  if (autohide) {
    open_sm_tab(last_active_sm_list);
    $("smilies_block").setStyle("display", "none");
  }
  $('message').setProperty("value",$('message').getProperty('value') + obj.title);
  $('message').focus();  
}

function send_report(id) {    
    $$(".send_state_text").each(function(elem,ind){
        elem.setStyles({color: "#F00000"});
        
        switch (id) {
            case 0: 
                elem.setHTML(t('YOU_WRITE_NOTHING'));
                break;
            case 1: 
                elem.setHTML(t('YOUR_MESSAGE_SUCCESFULLY_SENDED'));
                elem.setStyles({color: "#00D627"});
                break;
            case 2: 
                elem.setHTML(t('THE_SIZE_OF_THE_TEXT'));
                break;
        }
        $("message").setProperty("value",'');
        var fadeEffect = new Fx.Styles(elem, {duration: 2000, transition: Fx.Transitions.linear,onComplete: function() {
            fadeEffect.start({
                'opacity': 0
            });
            //elem.setStyle("display","none"); 
        }});
        elem.setStyles({"display":"block","opacity":0});
        fadeEffect.start({
            'opacity': 1
        });
    //alert("1");    
    })
}

function substr_count (haystack, needle, offset, length) {
    var pos = 0, cnt = 0;
     haystack += '';
    needle += '';
    if (isNaN(offset)) {offset = 0;}
    if (isNaN(length)) {length = 0;}
    offset--; 
    while ((offset = haystack.indexOf(needle, offset+1)) != -1){
        if (length > 0 && (offset+needle.length) > length){
            return false;
        } else{            cnt++;
        }
    }
 
    return cnt;}

function load_messages() {
    if($('channel')) var channel_value = $('channel').getValue();
    else var channel_value = "main"
    var url ="index.php?option=com_webchat&view=webchat&cf_update=1&last_msg_time="+ $('last_msg_time').getProperty('value')+"&channel="+ channel_value +"&connection_state_v="+connection_state;    
    var a = new Ajax( url, {
        method: 'get',
            onComplete: function(data) {
                //var result = eval("(" + data + ")");
                var result = Json.evaluate( data );
                $("last_msg_time").setProperty("value", result.last_msg_time);
                if (connection_state != result.connection_state && result.connection_state != undefined) {
                    var text = '';
                    var css_class = '';
                    switch (result.connection_state) {
                        case 1:
                            text = t('CONNECTION_TO_THE_SERVER_IS_NOT_STABLE');
                            css_class = 'unstable_conn';
                            break;
                        case 2:
                            text = t('CONNECTION_TO_THE_SERVER_IS_MISSING');
                            css_class = 'unactive_conn';
                        break;
                    }
                    
                    $$('.connection_state').each(function(elem,ind){
                        var fadeEffect2 = new Fx.Styles(elem, {duration: 2000, transition: Fx.Transitions.linear});
                        if (text != '') {
                            elem.setHTML(text).addClass(css_class);
                            fadeEffect2.start({
                                'opacity': [0, 1]
                            });
                        }else {
                            elem.removeClass('unstable_conn unactive_conn');
                            fadeEffect2.start({
                                'opacity': [1, 0]
                            });
                        }
                    })
                    connection_state = result.connection_state;
                }
                
                if (result.messages_array) {    
                    for (var mess in result.messages_array){
                        if(!substr_count(result.messages_array[mess],"function",0,10)){
                            var divparent = new Element('div');
                            divparent.setHTML(result.messages_array[mess]); 
                            divparent.getChildren().injectInside('messages_list');
                            $('messages_list').getChildren().each(function(el,ind){
                                if(el.getStyle("display") == "none"){
                                    el.setStyles({"display":"block","opacity":0})
                                    var fadeEffect3 = new Fx.Styles(el, {duration: 2000, transition: Fx.Transitions.linear});
                                    fadeEffect3.start({
                                        'opacity': [0, 1]
                                    });
                                }
                            }) 
                        }
                    }
                    if (is_notif_needed)
                        play_notif();
                        
                    var scroll = new Fx.Scroll('messages_list', {
                        wait: false,
                        duration: 500
                    });
                    setTimeout(function(){scroll.toBottom();} , 10);    
                }
                
                if (result.user_auth != undefined) {
                    var alt = t('STATE');
                    var answ_array = [
                        t('YOU_ARE_NOT_REGISTRED_IN_CHAT'),
                        t('ALREADY_IN_CHAT'),
                        t('WAITING_FOR_AUTHORIZATION'),
                        t('YOU_ARE_NOT_LOGGED_IN_ON_SAIT'),
                        t('TOO_MUCH_USERS_ONLINE'),
                        t('NICK_IS_OUT_OF_RULES'),
                        t('YOU_ARE_BANNED'),
                        t('NICK_INCLUDES_BAD_WORDS'),
                        t('NICK_IS_ALREADY_REGISTRED'),
                        t('TOO_MUCH_USERS_FROM_IP'),
                        t('ACTIVATION_REQUEST_SENDED'),
                        t('WRONG_PASSWORD'),
                        t('ACTIVATION_REQUEST_DENIED_OR_IN_PROGRESS')
                    ];
                    var tip = answ_array[result.user_auth];
                    var image;

                    if (result.user_auth == 0 || result.user_auth > 3)
                        image = t('URL')+"components/com_webchat/images/stat_error.png";    
                    else if (result.user_auth == 2)
                        image = t('URL')+"components/com_webchat/images/stat_wait.png";
                    else{
                        image = t('URL')+"components/com_webchat/images/stat_ok.png";
                        alt = t('ALREADY_IN_CHAT');
                        tip = t('CLICK_TO_CHANGE_STATE');
                    }

                    $$(".state").each(function(el,ind){
                        el.getElement("img").setProperty("alt", alt);
                        el.getElement("img").setProperty("title", alt);
                        el.getElement("img").setProperty("src", image);
                        
                        if (el.getElement("span").innerHTML != tip)
                            el.getElement("span").setHTML(tip);
                    })
                }

                if (result.actions_array)
                    do_actions(result.actions_array);
                //alert('dd');
                setTimeout('load_messages()',  1000);
            },
            onFailure: function() { 
                setTimeout('load_messages()',  5000);
            }
    }).request();
}

function do_actions(actions_array) {
    for (var action in actions_array) {
        var i, nick;
        switch (actions_array[action].type) {
            case "2": case "5":
                i = 0;
                //nick = $("#users_list ul li a:eq(" + i + ")").html();
                nick = $("users_list").getElement("ul").getElements("li")[i].getElement("a").innerHTML;
                while (nick) {
                    if (nick == actions_array[action].nick) {
                        //$("#users_list ul li:eq(" + i + ")").remove();
                        $("users_list").getElement("ul").getElements("li")[i].remove();
                        //$("#users_list ul div:eq(" + i + ")").remove();
                        //$("users_list").getElement("ul").getElements("li")[i].getElement("div").remove();
                        nick = null;
                    }else {
                        i++;
                        //nick = $("#users_list ul li a:eq(" + i + ")").html();
                        nick = $("users_list").getElement("ul").getElements("li")[i].getElement("a").innerHTML;
                    }
                }
                break;
            case "4":
                i = 0;
                //nick = $("#users_list ul li a:eq(" + i + ")").html();
                nick = $("users_list").getElement("ul").getElements("li")[i].getElement("a").innerHTML;
                var is_added = false;
                var show_ips = true;
                var form_nick = '<li class="single_user' + ((actions_array[action].male == 1) ? ' woman' : ' man') + '">' +
                                '<a class="nick_paste" onclick="insert_nick(\'' + actions_array[action].nick + '\')" >' + actions_array[action].nick + '</a>' + 
                                '<div class="user_info">' +
                                'IP: ' + ((/*Drupal.settings.cf_webchat.*/show_ips && actions_array[action].variable != 'N/A') ? actions_array[action].variable : t('HIDDEN')) + '<br />' +
                                t('STATE') + ': ' + t('UNDEFINED') + ' </div>' +
                                '</li>' +
                                '<div></div>';

                while (nick && !is_added) {
                    if (is_nick_higher(nick, actions_array[action].nick)) {
                        //$("#users_list ul li:eq(" + i + ")").before(form_nick);
                        //form_nick.injectBefore($("users_list").getElement("ul").getElements("li")[i]);
                        $("users_list").getElement("ul").getElements("li")[i].setProperty("id","li_id");
                        var divparent3 = new Element('div');
                        divparent3.setHTML(form_nick); 
                        divparent3.getChildren().injectBefore('li_id');
                    
                        is_added = true;    
                    }else {
                        i++;
                        //nick = $("#users_list ul li a:eq(" + i + ")").html();
                        nick = $("users_list").getElement("ul").getElements("li")[i].getElement("a").innerHTML;
                    }
                };
                if (!is_added){
                    //$("#users_list ul").append(form_nick);
                    //form_nick.injectInside($("users_list").getElement("ul"));
                    var divparent2 = new Element('div');
                    divparent2.setHTML(form_nick); 
                    divparent2.getChildren().injectInside('listusers');
                }
                break;
            case "8":
                //$(".channel_topic").html(actions_array[action].variable);
                $$(".channel_topic").each(function(elem,ind){
                    elem.setHTML(actions_array[action].variable);
                })
                break;
        }    
    }
}


